<footer class="main-footer">
                <div class="container">
                    <div class="pull-right hidden-xs"> <b>Version</b> 3.0.1</div>
                    <strong>Copyright &copy; 2017-2018 <a href="#">Mohan Mutha Group</a>.</strong> All rights reserved. 
                </div>
            </footer>