<?php
session_start();
//$db = new mysqli('localhost','root','','employee-edesk');
$db = new mysqli('localhost','root','','edesk');


if($db->connect_errno != 0){
    echo "connection failed error: " .$db->connect_error;
}


$sip = getHostByName(getHostName());

//$sip = $_SERVER['REMOTE_ADDR'];