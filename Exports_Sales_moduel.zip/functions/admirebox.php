<?php

/* $msg
1 = invalid credential
2 = Credentials Missmatch
3 = Please insert Different Credentials
4 = Password Changed Successfully
5 = Created Successfully
6 = Updated Successfully

*/




include 'config.php';

// ===================================================================================================== Login section Starts Here =============================================================================================================


// user login starts
    
if(!empty($_POST['eid'])){
    $eid = $_POST['eid'];
    $pass = $_POST['pass'];
    $pass = md5($pass);
    $login = "SELECT * FROM users WHERE eid = '$eid' AND pass = '$pass'";

    $login = $db->query($login);
    

    if($login->num_rows >0){
        $ulogin=$login->fetch_object();
        $chid = $ulogin->id;
        if(!empty($chid)){
            $change = "SELECT * FROM users WHERE id=$chid";
            $chang = $db->query($change);
            $chan = $chang->fetch_object();
            $chanid = $chan->id;
            $chanam = md5($chan->name);
            $chapass = $chan->pass;
            $chapaypass = $chan->paypass;
            if($chanam == $chapass && $chanam == $chapaypass){
                header("Location: ../login.php?changu=$chanid");
            }else{
                $_SESSION['userid'] = $chanid;
                header("Location: ../dashboard.php");
            }
        }
        
    }else{
        header("Location: ../login.php?msg=1");
    }
}


// user login ends
// Change Default Password Starts
if(!empty($_POST['newpass'])){
    $newpass = $_POST['newpass'];
    $newcpass = $_POST['newcpass'];
    $paypass = $_POST['paypass'];
    $cpaypass = $_POST['cpaypass'];
    $id = $_POST['emid'];
    if($newpass != $paypass){
        if($newpass == $newcpass && $paypass == $cpaypass){
            $newpass = md5($newpass);
            $paypass = md5($paypass);
            $change = "UPDATE users SET pass = '$newpass', paypass = '$paypass' WHERE id=$id";
            $chang = $db->query($change);
            if($chang > 0){
                header("Location: ../login.php?msg=4");
            }
        }else{
            header("Location: ../login.php?changu=$id&msg=2");
        }
    }else{
        header("Location: ../login.php?changu=$id&msg=3");
    }
}
// Change Default Password Ends
// Forgot Password Starts
if(!empty($_POST['forgot'])){
    $empid = $_POST['forgot'];
    $fogrand = rand(12456,123456789);
    $forg = "UPDATE users SET randlog = '$fogrand' WHERE eid = '$empid'";
    $forge = $db->query($forg);
    
    if($forge > 0){
        header("Location: ../login.php?forgot=1&fogrand=$fogrand");
    }
    
}
// Forgot Password Starts
// check ip starts

// check ip ends

// ===================================================================================================== Login section ends Here =============================================================================================================

// ===================================================================================================== Customer section Starts Here =============================================================================================================


// add new customer
if(!empty($_POST["cname"])){
        $cname = $_POST ["cname"];
        $cpname = $_POST ["cpname"];
        $cdes = $_POST ["cdes"];
        $cemail = $_POST ["cemail"];
        $cpnumber = $_POST["cpnumber"];
        $cmnumber = $_POST ["cmnumber"];
        $cdport = $_POST ["cdport"];
        $cfinald = $_POST ["cfinald"];
        $cpaym = $_POST ["cpaym"];
        $curl = $_POST ["curl"];
        $cgroup = $_POST ["cgroup"];
        $cproduct = $_POST ["cproduct"];
        $cbank = $_POST ["cbank"];
        $caddress = $_POST ["caddress"];
        $caddress = mysqli_real_escape_string($db,$caddress);


        $iquery = "INSERT INTO `customers` (`id`, `cname`, `cpname`, `cdes`, `cemail`, `cpnumber`, `cmnumber`, `cdport`, `cfinald`, `cpaym`, `curl`, `cgroup`, `cproduct`, `cbank`, `caddress`, `created`, `updated`) VALUES (NULL, '$cname', '$cpname', '$cdes', '$cemail', '$cpnumber', '$cmnumber', '$cdport', '$cfinald', '$cpaym', '$curl', '$cgroup', '$cproduct', '$cbank', '$caddress', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $res= $db->query($iquery);
        if($res > 0){
            header("Location: ../customers.php?msg=5");
        }
    
}
// add new customer

// update new customer
if(!empty($_POST["upcname"])){
        $cname = $_POST ["upcname"];
        $cpname = $_POST ["upcpname"];
        $cdes = $_POST ["upcdes"];
        $cemail = $_POST ["upcemail"];
        $cpnumber = $_POST["upcpnumber"];
        $cmnumber = $_POST ["upcmnumber"];
        $cdport = $_POST ["upcdport"];
        $cfinald = $_POST ["upcfinald"];
        $cpaym = $_POST ["upcpaym"];
        $curl = $_POST ["upcurl"];
        $cgroup = $_POST ["upcgroup"];
        $cproduct = $_POST ["upcproduct"];
        $cbank = $_POST ["upcbank"];
        $caddress = $_POST ["upcaddress"];
        $caddress = mysqli_real_escape_string($db,$caddress);
    $id = $_POST['cid'];

        $iquery = "UPDATE customers SET cname = '$cname', cpname = '$cpname', cdes = '$cdes', cemail = '$cemail', cpnumber = '$cpnumber', cmnumber = '$cmnumber', cdport = '$cdport', cfinald = '$cfinald', cpaym = '$cpaym', curl = '$curl', cgroup = '$cgroup', cproduct = '$cproduct', cbank = '$cbank', caddress = '$caddress' WHERE id = '$id'";
        $res= $db->query($iquery);
        if($res > 0){
            header("Location: ../customers.php?msg=6");
        }
    
}
// update new customer
// Delete customer
if(!empty($_GET['cdelete'])){
    $id= $_GET['cdelete'];
    $delete = "DELETE FROM customers WHERE id= $id";
    $res= $db->query($delete);
    if($res > 0){
        header("Location: ../customers.php?msg=7");
    }
}
// Delete customer

// ===================================================================================================== Customer section Ends Here =============================================================================================================
// ===================================================================================================== Enquiry section Starts Here =============================================================================================================

// add new customer
if(!empty($_POST["ecname"])){
        $cname = $_POST ["ecname"];
        $cpname = $_POST ["ecpname"];
        $cdes = $_POST ["ecdes"];
        $cemail = $_POST ["ecemail"];
        $cpnumber = $_POST["ecpnumber"];
        $cmnumber = $_POST ["ecmnumber"];
        $cdport = $_POST ["ecdport"];
        $cfinald = $_POST ["ecfinald"];
        $cpaym = $_POST ["ecpaym"];
        $curl = $_POST ["ecurl"];
        $cgroup = $_POST ["ecgroup"];
        $cproduct = $_POST ["ecproduct"];
        $cbank = $_POST ["ecbank"];
        $caddress = $_POST ["ecaddress"];



        $iquery = "INSERT INTO `customers` (`id`, `cname`, `cpname`, `cdes`, `cemail`, `cpnumber`, `cmnumber`, `cdport`, `cfinald`, `cpaym`, `curl`, `cgroup`, `cproduct`, `cbank`, `caddress`, `created`, `updated`) VALUES (NULL, '$cname', '$cpname', '$cdes', '$cemail', '$cpnumber', '$cmnumber', '$cdport', '$cfinald', '$cpaym', '$curl', '$cgroup', '$cproduct', '$cbank', '$caddress', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $res= $db->query($iquery);
        if($res > 0){
            header("Location: ../enquiry.php?enq=1&msg=5");
        }
    
}
// add new customer
// add new Enquiry

if(!empty($_POST['name'])){
    $name = $_POST['name'];
    $doe = $_POST['doe'];
    $moe = $_POST['moe'];
    $pn = $_POST['pn'];
    $pd = $_POST['pd'];
    $pq = $_POST['pq'];
    $qr = $_POST['qr'];
    $ep = $_POST['ep'];
    $ds = $_POST['ds'];
    $pr = $_POST['pr'];
    $lr = $_POST['lr'];
    $lb = $_POST['lb'];
    $otr = $_POST['otr'];
    $ad = $_POST['ad'];
    $cfeas = $_POST['cfeas'];
    $pfeas = $_POST['pfeas'];
    $lfeas = $_POST['lfeas'];
    $sc = $_POST['sc'];
    $director = $_POST['director'];
                                    switch ($director) {
                                    case 1:
                                        $bdm = "Managing Director";
                                        break;
                                    case 2:
                                        $bdm = "Director";
                                        break;
                                    case 3:
                                        $bdm = "BDM";
                                        break;
                                    case 4:
                                        $bdm = "BDM";
                                        break;
                                            
                                }
    
    // insert main form 
     $iquery= "INSERT INTO `enquiry` (`id`, `name`, `doe`, `moe`, `pn`, `pd`, `pq`, `qr`, `ep`, `ds`, `pr`, `lr`, `lb`, `otr`, `ad`, `cfeas`, `pfeas`, `lfeas`, `sc`, `bdm`, `director`, `created`, `modified`) VALUES (NULL, '$name', '$doe', '$moe', '$pn', '$pd', '$pq', '$qr', '$ep', '$ds', '$pr', '$lr', '$lb', '$otr', '$ad', '$cfeas', '$pfeas', '$lfeas', '$sc', '$bdm', '$director', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
    
    $in = $db->query($iquery);
    //ionsertid
    if($in > 0){
        header("Location: ../enquiry.php?&msg=5");
    }
}

// add new Enquiry
// Update Enquiry

if(!empty($_POST['ename'])){
    $name = $_POST['ename'];
    $doe = $_POST['edoe'];
    $moe = $_POST['emoe'];
    $pn = $_POST['epn'];
    $pd = $_POST['epd'];
    $pq = $_POST['epq'];
    $qr = $_POST['eqr'];
    $ep = $_POST['eep'];
    $ds = $_POST['eds'];
    $pr = $_POST['epr'];
    $lr = $_POST['elr'];
    $lb = $_POST['elb'];
    $otr = $_POST['eotr'];
    $ad = $_POST['ead'];
    $cfeas = $_POST['ecfeas'];
    $pfeas = $_POST['epfeas'];
    $lfeas = $_POST['elfeas'];
    $sc = $_POST['esc'];
    $id = $_POST['id'];
    $director = $_POST['edirector'];
                                    switch ($director) {
                                    case 1:
                                        $bdm = "Managing Director";
                                        break;
                                    case 2:
                                        $bdm = "Director";
                                        break;
                                    case 3:
                                        $bdm = "Manager Exports";
                                        break;
                                    case 4:
                                        $bdm = "Manager Exports";
                                        break;
                                            
                                }
    // insert main form 
     $iquery= "UPDATE enquiry SET `name` ='$name', `doe`='$doe', `moe`='$moe', `pn`='$pn', `pd`='$pd', `pq`='$pq', `qr`='$qr', `ep`='$ep', `ds`='$ds', `pr`='$pr', `lr`='$lr', `lb`='$lb', `otr`='$otr', `ad`='$ad', `cfeas`='$cfeas', `pfeas`='$pfeas', `lfeas`='$lfeas', `sc`='$sc', `bdm`='$bdm', `director`='$director' WHERE id=$id";
    
    $in = $db->query($iquery);
    //ionsertid
    if($in > 0){
        header("Location: ../enquiry.php?&msg=6");
    }
}

// Update Enquiry
// Delete customer
if(!empty($_GET['edelete'])){
    $id= $_GET['edelete'];
    $delete = "DELETE FROM enquiry WHERE id= $id";
    $res= $db->query($delete);
    if($res>0){
        $select ="SELECT * FROM parent WHERE eid=$id";
            $selec = $db->query($select);
        $sele = $selec->fetch_object();
        $raid = $sele->randi;
    $delet = "DELETE FROM parent WHERE randi=$raid";
    $del = $db->query($delet);
    if($del > 0){
    $delete = "DELETE FROM orders WHERE randid= $raid";
    $res= $db->query($delete);
    if($res > 0){
        header("Location: ../enquiry.php?msg=7");
    }
    }
}
}

// Delete customer

// ===================================================================================================== Enquiry section Ends Here =============================================================================================================
// ===================================================================================================== Orders section Ends Here =============================================================================================================
if(!empty($_FILES['file'])){
    $cid =$_POST['enid'];
    if(!empty($cid)){
        $enqdet = "SELECT * FROM enquiry WHERE id= $cid";
        $enqde = $db->query($enqdet);
        $enq = $enqde->fetch_object();
        $sc = $enq->sc;
        $director = $enq->director;
        $randi = $_POST['randi'];
        $revi = $_POST['revi'];
    $enid =$_POST['enid'];
    $note =$_POST['note'];
    }
    $randi = $_POST['randi'];
    $filename=$_FILES["file"]["tmp_name"];
		

		 if($_FILES["file"]["size"] > 0)
		 {
            
		  	$file = fopen($filename, "r");
             $row = 0;
             while((fgetcsv($file)) != FALSE){
                 $row++;
             }
             $sel = $row;
                if(!empty($sel)){
                    $iquery= "INSERT INTO `parent` (`id`,`eid`, `sel`, `cid`, `salec`, `director`, `randi`, `note`, `created`, `modified`) VALUES (NULL, '$enid', '$sel', '$cid', '$sc','$director','$randi','$note', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
    
    $in = $db->query($iquery);
                    if(!empty($in)){
                        $count = "SELECT * FROM parent";
                        $coun = $db->query($count);
                        $cou = $coun->num_rows;
                    }
                    
                }fclose($file);
             $file = fopen($filename, "r");
	         while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
	           $i++;
    if($i==1) continue;
	          //It wiil insert a row to our subject table from our csv file`
	           $sql = "INSERT INTO `orders` (`id`, `prid`, `enid`, `randid`, `revi`, `slno`, `pname`, `des`, `catid`, `qty`, `uom`, `rate`, `total`, `cost1`, `wepc`, `cost2`, `pac`, `hand`, `lfrt`, `otrchr`, `conv`, `usdprice`, `usdt`, `sftr`, `ins`, `pftv`, `usdoc`, `cif`, `created`, `modified`) VALUES (NULL, '$cou', '$enid', '$randi', '$revi', '$emapData[0]', '$emapData[1]', '$emapData[2]', '$emapData[3]', '$emapData[4]', '$emapData[5]', '$emapData[6]', '$emapData[7]', '$emapData[8]', '$emapData[9]', '$emapData[10]', '$emapData[11]', '$emapData[12]', '$emapData[13]', '$emapData[14]', '$emapData[15]', '$emapData[16]', '$emapData[17]', '$emapData[18]', '$emapData[19]', '$emapData[20]', '$emapData[21]', '$emapData[22]', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);";
                   
                   
	         //we are using mysql_query function. it returns a resource on true else False on error
	          $result = $db->query($sql);
               
				if(! $result )
				{
					echo "<script type=\"text/javascript\">
							alert(\"Invalid File:Please Upload CSV File.\");
							window.location = \"index.php\"
						</script>";
				
				}

	         }
	         fclose($file);
	         //throws a message if data successfully imported to mysql database from excel file
	        if($result > 0){
                header("Location: ../order.php?id=$enid&msg=5");
            }
			 

			 //close of connection
			mysql_close($db); 
}

}

     //order update starts here
  
        
if(isset($_POST['orup'])){
    $randi = $_POST['randi'];
    $select = "SELECT * FROM parent WHERE randi=$randi";
        $sel = $db->query($select);
        $se = $sel->fetch_object();
        $num = $se->sel;
    $eid = $se->eid;
        $num = $num-1;
    for($f=1;$f<=$num;$f++){
        if(!empty($_POST['oid'.$f])){
            $oid = $_POST['oid'.$f];
        }
        if(!empty($_POST['sln'.$f])){
            $sln = $_POST['sln'.$f];
        }
        if(!empty($_POST['prd'.$f])){
            $prd = $_POST['prd'.$f];
        }
        if(!empty($_POST['prdes'.$f])){
            $prdes = $_POST['prdes'.$f];
        }
        if(!empty($_POST['qty'.$f])){
            $qty = $_POST['qty'.$f];
        }
        if(!empty($_POST['uom'.$f])){
            $uom = $_POST['uom'.$f];
        }
        if(!empty($_POST['rpu'.$f])){
            $rpu = $_POST['rpu'.$f];
        }
        if(!empty($_POST['ta'.$f])){
            $ta = $_POST['ta'.$f];
        }
        if(!empty($_POST['cst1'.$f])){
            $cst1 = $_POST['cst1'.$f];
        }
        if(!empty($_POST['wei'.$f])){
            $wei = $_POST['wei'.$f];
        }
        if(!empty($_POST['cst2'.$f])){
            $cst2 = $_POST['cst2'.$f];
        }
        if(!empty($_POST['pck'.$f])){
            $pck = $_POST['pck'.$f];
        }
        if(!empty($_POST['hnd'.$f])){
            $hnd = $_POST['hnd'.$f];
        }
        if(!empty($_POST['lfrt'.$f])){
            $lfrt = $_POST['lfrt'.$f];
        }
        if(!empty($_POST['otr'.$f])){
            $otr = $_POST['otr'.$f];
        }
        if(!empty($_POST['cfact'.$f])){
            $cfact = $_POST['cfact'.$f];
        }
        if(!empty($_POST['usdp'.$f])){
            $usdp = $_POST['usdp'.$f];
        }
        if(!empty($_POST['usdt'.$f])){
            $usdt = $_POST['usdt'.$f];
        }
        if(!empty($_POST['sfrt'.$f])){
            $sfrt = $_POST['sfrt'.$f];
        }
        if(!empty($_POST['ins'.$f])){
            $ins = $_POST['ins'.$f];
        }
        if(!empty($_POST['ptv'.$f])){
            $ptv = $_POST['ptv'.$f];
        }
        if(!empty($_POST['oth'.$f])){
            $oth = $_POST['oth'.$f];
        }
        if(!empty($_POST['cif'.$f])){
            $cif = $_POST['cif'.$f];
        }
        $updat = "UPDATE orders SET 
        slno = '".(!empty($sln) ? $sln : "")."',
        pname = '".(!empty($prd) ? $prd : "")."',
        des = '".(!empty($prdes) ? $prdes : "")."',
        qty ='".(!empty($qty) ? $qty : "")."', 
        uom = '".(!empty($uom) ? $uom : "")."', 
        rate = '".(!empty($rpu) ? $rpu : "")."', 
        total = '".(!empty($ta) ? $ta : "")."', 
        cost1 = '".(!empty($cst1) ? $cst1 : "")."', 
        wepc = '".(!empty($wei) ? $wei : "")."', 
        cost2 = '".(!empty($cst2) ? $cst2 : "")."', 
        pac = '".(!empty($pck) ? $pck : "")."', 
        hand = '".(!empty($hnd) ? $hnd : "")."', 
        lfrt = '".(!empty($lfrt) ? $lfrt : "")."', 
        otrchr = '".(!empty($otr) ? $otr : "")."', 
        conv = '".(!empty($cfact) ? $cfact : "")."', 
        usdprice = '".(!empty($usdp) ? $usdp : "")."',
        usdt = '".(!empty($usdt) ? $usdt : "")."', 
        sftr = '".(!empty($sfrt) ? $sfrt : "")."', 
        ins = '".(!empty($ins) ? $ins : "")."', 
        pftv = '".(!empty($ptv) ? $ptv : "")."',
        cif = '".(!empty($cif) ? $cif : "")."',
        modified = CURRENT_TIMESTAMP
        WHERE id=$oid";
        $upd = $db->query($updat);
        
        
    }
    if($upd > 0){
        header("Location: ../order.php?id=$eid");
    }
}

//delete single product
if(!empty ($_GET['ordelid'])){
    $id = $_GET['ordelid'];
    $enid = $_GET['enid'];
    $orid = $_GET['randi'];
  $delete = "DELETE FROM orders WHERE id= $id";
    $res= $db->query($delete);
    if($res > 0){
        $select = "SELECT * FROM parent WHERE randi=$orid";
        $sel = $db->query($select);
        $se = $sel->fetch_object();
        $num = $se->sel;
        $num = $num-1;
        $updat = "UPDATE parent SET sel=$num WHERE randi=$orid";
        $upd = $db->query($updat);
        
        if($upd == 1){
        header("Location: ../order.php?edito=1&enid=$enid&orid=$orid");
        }
    }
}
    //order update ends here
// ===================================================================================================== Orders section Ends Here =============================================================================================================
// ===================================================================================================== Category section Starts Here =============================================================================================================
    
// Delete Category
if(!empty($_GET['catdelete'])){
    $id= $_GET['catdelete'];
    $ord= $_GET['ord'];
    $delete = "DELETE FROM categories WHERE id= $id";
    $res= $db->query($delete);
    if($res > 0){
        header("Location: ../order.php?id=$ord&cmsg=7");
    }
}
// Delete Category
//add category
if(!empty($_POST['cat'])){
    $ord= $_POST['ord'];
    $cat = $_POST['cat'];
    $iquery = "INSERT INTO `categories` (`id`, `cname`, `created`, `updated`) VALUES (NULL, '$cat', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $res= $db->query($iquery);
    if($res > 0){
        header("Location: ../order.php?id=$ord&cmsg=5");
    }
}
//add category
    
// ===================================================================================================== Category section Ends Here =============================================================================================================
// ===================================================================================================== Pricing sheet section Starts Here ========================================================================================================
   
// Delete pricing sheet
if(!empty($_GET['prdelete'])){
    $id= $_GET['prdelete'];
    $ord= $_GET['ord'];
    $delet = "DELETE FROM parent WHERE randi=$id";
    $del = $db->query($delet);
    if($del > 0){
    $delete = "DELETE FROM orders WHERE randid= $id";
    $res= $db->query($delete);
    if($res > 0){
        header("Location: ../order.php?id=$ord&cmsg=7");
    }
}
}
// Delete pricing sheetss
// ===================================================================================================== Pricing sheet section Ends Here ==========================================================================================================
// ===================================================================================================== Quotation section Starts Here ==========================================================================================================
//add new quoation
if(!empty($_POST['quote'])){
    $quote = $_POST['quote'];
    $sub = $_POST['sub'];
    $ordid = $_POST['ordid'];
    $radid = $_POST['radid'];
    $iquery = "INSERT INTO `quotation` (`id`, `ordid`, `quote`, `sub`, `radid`, `created`, `updated`) VALUES (NULL, '$ordid', '$quote', '$sub', '$radid', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $res= $db->query($iquery);
    if($res > 0){
        header("Location: ../quote.php?id=$ordid&orid=$radid&cmsg=5");
    }
    
    
}
//add new quotation
//update quotation

if(!empty($_POST['equote'])){
    $equote = $_POST['equote'];
    $esub = $_POST['esub'];
    $ordid = $_POST['ordid'];
    $radid = $_POST['radid'];
    $qid = $_POST['qid'];
    $iquery = "UPDATE quotation SET quote = '$equote', sub = '$esub' WHERE id=$qid";
        
        $res= $db->query($iquery);
    if($res > 0){
        header("Location: ../quote.php?id=$ordid&orid=$radid&cmsg=6");
    }
    
    
}
//update quotation
//delete quotation
if(!empty($_GET['qdelete'])){
    $id = $_GET['qdelete'];
    $delete = "DELETE FROM quotation WHERE id= $id";
    $res= $db->query($delete);
    if($res > 0){
        header("Location: ../quote.php?id=$ord&cmsg=7");
    }
}

//delete quotation

// ===================================================================================================== Quotation section Ends Here ==========================================================================================================


// ===================================================================================================== Payroll Starts Here ==========================================================================================================
//add employes

if(!empty($_POST['emname'])){
    $name = $_POST['emname'];
    $pass = md5($name);
    $paypass = md5($name);
    $email = $_POST['email'];
    $number = $_POST['number'];
    $eid = $_POST['eeid'];
    $emtype = $_POST['emtype'];
    $designation = $_POST['designation'];
    $goc = $_POST['goc'];
    $depart = $_POST['depart'];
    $doj = $_POST['doj'];
    $loc = $_POST['loc'];
    $gross = $_POST['gross'];
    $bac = $_POST['bac'];
    $epf = $_POST['epf'];
    $esi = $_POST['esi'];
    $userrole = $_POST['userrole'];
    $iquery = "INSERT INTO `users` (`id`, `name`, `email`, `pass`, `paypass`, `number`, `eid`, `emtype`, `designation`, `goc`, `depart`, `doj`, `loc`, `gross`, `bac`, `epf`, `esi`, `userrole`, `created`, `updated`) VALUES (NULL, '$name', '$email', '$pass', '$paypass', '$number', '$eid', '$emtype', '$designation', '$goc', '$depart', '$doj', '$loc', '$gross', '$bac', '$epf', '$esi', '$userrole', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        //print_r($iquery); exit();
        $res= $db->query($iquery);
    if($res == 1){
        $res = 5;
    }else{
        $res=2;
    }
            header("Location: ../pay.php?msg=$res");
}
//add employes
//delete employes
if(!empty($_GET['pdelete'])){
    $id= $_GET['pdelete'];
    $delete = "DELETE FROM users WHERE id= $id";
    $res= $db->query($delete);
    if($res == 1){
        $res = 7;
    }else{
        $res=2;
    }
    header("Location: ../pay.php?msg=$res");
}
//delete employes
//Edit employes
if(!empty($_POST['edemname'])){
    $id=$_POST['edid'];
    $name = $_POST['edemname'];
    $email = $_POST['edemail'];
    $number = $_POST['ednumber'];
    $eid = $_POST['edeeid'];
    $emtype = $_POST['edemtype'];
    $designation = $_POST['eddesignation'];
    $goc = $_POST['edgoc'];
    $depart = $_POST['eddepart'];
    $doj = $_POST['eddoj'];
    $loc = $_POST['edloc'];
    $gross = $_POST['edgross'];
    $bac = $_POST['edbac'];
    $epf = $_POST['edepf'];
    $esi = $_POST['edesi'];
    $userrole = $_POST['eduserrole'];
    //echo "test"; exit();
    
    $iquery= "UPDATE users SET `name` ='$name', `email`='$email', `number`='$number', `eid`='$eid', `emtype`='$emtype', `designation`='$designation', `goc`='$goc', `depart`='$depart', `doj`='$doj', `loc`='$loc', `gross`='$gross', `bac`='$bac', `epf`='$epf', `esi`='$esi', `userrole`='$userrole', `updated`='CURRENT_TIMESTAMP' WHERE id=$id";
    //print_r($iquery); exit();
    $res = $db->query($iquery);
    
    if($res == 1){
        $res = 6;
    }else{
        $res=2;
    }
            header("Location: ../pay.php?msg=$res");
}
//Edit employes
//insert payroll



if(!empty($_POST['payid'])){
    
    $payid      = $_POST['payid'];
    $month      = $_POST['month'];
    $year       = $_POST['year'];
    $dim        = $_POST['dim'];
    $lop        = $_POST['lop'];
    $dw         = $_POST['dw'];
    $basicg     = $_POST['basicg'];
    $dag        = $_POST['dag'];
    $hrag       = $_POST['hrag'];
    $conveyg    = $_POST['conveyg'];
    $mediag     = $_POST['mediag'];
    $tgross     = $_POST['tgross'];
    $basice     = $_POST['basice'];
    $dae        = $_POST['dae'];
    $hrae       = $_POST['hrae'];
    $conveye    = $_POST['conveye'];
    $medicale   = $_POST['medicale'];
    $bonuse   = $_POST['bonuse'];
    $otherse    = $_POST['otherse'];
    $egross     = $_POST['egross'];
    $epf        = $_POST['epf'];
    $esi        = $_POST['esi'];
    $staff      = $_POST['staff'];
    $tds        = $_POST['tds'];
    $othersd    = $_POST['othersd'];
    $totald    = $_POST['totald'];
    $netpay     = $_POST['netpay'];
    //print_r($netpay); exit();
    $rand     = $_POST['rand'];
    
    $upay= "INSERT INTO `upay` (`id`,`payid`,`month`, `year`,`dim`, `lop`, `dw`, `basicg`, `dag`, `hrag`, `conveyg`,`mediag`, `tgross`, `basice`, `dae`, `hrae`, `conveye`, `medicale`, `bonuse`, `otherse`, `egross`, `epf`, `esi`, `staff`, `tds`, `othersd`, `totald`, `netpay`, `rand`, `created`, `modified`) VALUES(NULL,'$payid','$month','$year','$dim','$lop','$dw','$basicg','$dag','$hrag','$conveyg','$mediag','$tgross','$basice','$dae','$hrae','$conveye','$medicale','$bonuse','$otherse','$egross','$epf','$esi','$staff','$tds','$othersd','$totald','$netpay','$rand',CURRENT_DATE, CURRENT_TIMESTAMP)";
            
            //echo $riquery;
            
            $res = $db->query($upay); 
    if($res == 1){
        $res = 6;
    }else{
        $res=2;
    }
            header("Location: ../pay.php?id=$payid&gpay=1&msg=$res");
}

//insert payroll
//delete payslip
if(!empty($_GET['paydelete'])){
    $id= $_GET['paydelete'];
    $delete = "DELETE FROM upay WHERE rand= $id";
    $res= $db->query($delete);
    if($res == 1){
        $res = 7;
    }else{
        $res=2;
    }
    header("Location: ../pay.php?msg=$res");
}
//delete payslip
//payslip login
if(!empty($_POST['payslippass'])){
    $usid = $_POST['userid'];
    $payslippass = $_POST['payslippass'];
    
    if(!empty($usid)){
        $eq = "SELECT * FROM users WHERE id = $usid";
    $eq = $db->query($eq);
$eq = $eq->fetch_object();
    
    $paypass = $eq->paypass;
       
    }
    if(!empty($paypass)){
        $payslippass = md5($payslippass);
        
    }
    
    if($payslippass == $paypass){
        $rand = rand(12456,123456789);
        $iquery = "UPDATE users SET randlog = '$rand' WHERE id=$usid";
        
        $res= $db->query($iquery);
    if($res > 0){
        header("Location: ../payslip.php?randlog=$rand");
    }
    }else{
       header("Location: ../payslip.php?msg=1"); 
    }
}

//payslip login

//reset Password

if(!empty($_POST['resetid'])){
    $rid = $_POST['resetid'];
    $resetcode=$_POST['resetcode'];
    $sel = "SELECT * FROM users WHERE id= $rid";
    $sele = $db->query($sel);
    $selec = $sele->fetch_object();
    $rename = $selec->name;
    $restrand = $selec->randlog; 
    //echo $resetcode. " , " .$restrand; exit();
    if($resetcode == $restrand){
    $repass = md5($rename);
    //print_r($rename. "," .$repass); exit ();
    $reupdate = "UPDATE users SET pass= '$repass', paypass= '$repass' WHERE id=$rid";
    $reup = $db->query($reupdate);
        header("Location: ../pay.php?msg=6");
    
    }else{
        header("Location: ../pay.php?msg=8");
    }
    }

//reset Password

// ===================================================================================================== Payroll Ends Here ==========================================================================================================

// ===================================================================================================== Confrom Product Starts Here ==========================================================================================================


if(isset($_POST['concheck'])){
   $orid = $_POST['conran'];
    if(!empty($orid)){
        $order = "SELECT * FROM orders WHERE randid=$orid";
        $orn = $db->query($order);
        $ornum = $orn->num_rows;
        
    }
    $i=1;
    for($x=0; $x<=$ornum; $x++){
        
     $conprod = $_POST["conprod$i"];
    
    echo $conprod;
        $i++;
    }
}



// ===================================================================================================== Confrom Product Ends Here ==========================================================================================================



?>