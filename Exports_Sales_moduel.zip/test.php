<?php 
 include'functions/config.php';


if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}

//error_reporting(0);
$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

$year =  2018;
$nyear = $year+1;
if(!empty($_GET['eid'])){
    
    $eid = $_GET['eid'];

$eq = "SELECT * FROM enquiry WHERE id = $eid";
    $eq = $db->query($eq);
$eq = $eq->fetch_object();
    $id = $eq->id;
    $id=sprintf("%04d", $id);
    $name = $eq->name;
    if(!empty($name));{
                                    $name = "SELECT * FROM customers WHERE id = $name";
                                    $name = $db->query($name);
                                    $name = $name->fetch_object();
                                    $name = $name->cname;
                                }
    $doe = strtotime($eq->doe);
    $doe = date("d/m/20y",$doe);
    $moe = $eq->moe;
    $pn = $eq->pn;
    $pd = $eq->pd;
    $pq = $eq->pq;
    $qr = $eq->qr;
    $ep = $eq->ep;
    $ds = $eq->ds;
    $pr = $eq->pr;
    $lr = $eq->lr;
    $lb = $eq->lb;
    $otr = $eq->otr;
    $ad = $eq->ad;
    $cfeas = $eq->cfeas;
    $pfeas = $eq->pfeas;
    $lfeas = $eq->lfeas;
    $sc = $eq->sc;
    $bdm = $eq->bdm;
    $director = $eq->director;
    $created = strtotime($eq->created);
    $created = date("d/m/20y",$created);



//A4 width 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
require ('fpdf/fpdf.php');
$pdf = new FPdF('p','mm','A4');
$pdf->SetMargins(20,20,0);
$pdf->AddPage();



$pdf->Image("eformlogo.png",20,20,0,0);
//customer feasibility
if($cfeas == 1){
$pdf->Image("1.png",126,61,0,0);
}else{
$pdf->Image("1.png",170,61,0,0);
}
//Product feasibility
if($pfeas == 1){
$pdf->Image("1.png",126,70,0,0);
}else{
$pdf->Image("1.png",170,70,0,0);
}
//Lead feasibility
if($lfeas == 1){
$pdf->Image("1.png",79,191,0,0);
}else{
$pdf->Image("1.png",165,191,0,0);
}

$pdf->SetFillColor(221, 217, 196);
//set font arial, bold, 14pt
$pdf->SetFont('Arial','B',14);
//Cell(width, height , text , border , end line , [align] );
$pdf->Cell(10, 10, '',1,0);
$pdf->Cell(160 ,10,'Mohan Mutha Exports Pvt Ltd.',1,1,'C',true);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(170 ,8,'Enquiry Feasibility Study Report',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,5,'Format No.:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(40 ,5,'SALES/FMT/011',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,5,'Date:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(50 ,5,$created,1,1,'C');//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,8,'Customer Name:',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(60 ,8,$name,1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(35 ,4,'Quote Ref No:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(35 ,4,"MME/$year-$nyear/".$id,1,1,'C');
$pdf->Cell(100,4,'',0,0);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(35 ,4,'En. Date:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(35 ,4,$doe,1,1,'C');


$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,8,'Mode of Enquiry Recieved',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,8,$moe,1,1,'C');


$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'Feasibility Review',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(80 ,5,'Have we dealt with the customer before?',1,0,'L');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(20 ,5,'Yes',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(22 ,5,'',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(20 ,5,'No',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(28 ,5,'',1,1,'C');

$pdf->Cell(170,4,'',1,1);

$pdf->SetFont('Arial','B',8);
$pdf->Cell(80 ,5,'Have we dealt with the Product before?',1,0,'L');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(20 ,5,'Yes',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(22 ,5,'',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(20 ,5,'No',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(28 ,5,'',1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,5,'Product Name',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(130 ,5,$pn,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,12,'Description of Item',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(130 ,12,$pd,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,8,'Quantity',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(130 ,8,$pq,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,12,'Quality Requirements (Incl. of certificate if any)',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,12,(!empty($qr) ? $qr : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,5,"Customer's Expectation Price",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,5,(!empty($ep) ? $ep : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,10,"Delivery Schedule",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,10,(!empty($ds) ? $ds : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,10,"Packaging Requirements",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,10,(!empty($pr) ? $pr : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,10,"Legal Requirements",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,10,(!empty($lr) ? $lr : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,10,"Labelling Requirements",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,10,(!empty($lb) ? $lb : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,10,"Other Requirements",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,10,(!empty($otr) ? $otr : 'N/A'),1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,5,"Sales Co-ordinator's name",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,5,$sc,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(70 ,12,"Signature",1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(100 ,12,'',1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'Results of Review',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Feasible',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10,'',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Not Feasible',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10, '',1,1,'C');//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'Ammendment details',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,10,'',1,1,'C');//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'Business Development Manager',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Signature',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10,'',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Date',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10,'',1,1,'C');//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'Director (Sales & Business Development)',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Signature',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10,'',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(42.5 ,10,'Date',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(42.5 ,10,'',1,1,'C');//end of line
}

if(!empty($_GET['cid'])){
   $cid = $_GET['cid']; 

    
    
 $cuquery = "SELECT * FROM customers WHERE id = $cid";
    $cuquery = $db->query($cuquery);
$c = $cuquery->fetch_object();
$cid = $c->id;
$cname = $c->cname;
$cpname = $c->cpname;
$cdes = $c->cdes;
$cemail = $c->cemail;
$cpnumber = $c->cpnumber;
$cmnumber = $c->cmnumber;
$cdport = $c->cdport;
$cfinald = $c->cfinald;
$cpaym = $c->cpaym;
$curl = $c->curl;
$cgroup = $c->cgroup;
$cproduct = $c->cproduct;
$cbank = $c->cbank;
$caddress = $c->caddress;
$cdate = strtotime($c->created);
    $cdate = date("d/m/20y",$cdate);
//print_r($caddress);
    
//A4 width 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
require ('fpdf/fpdf.php');
$pdf = new FPdF('p','mm','A4');
$pdf->SetMargins(20,20,0);
$pdf->AddPage();

    
$pdf->Image("eformlogo.png",20,20,0,0);
$pdf->SetFillColor(221, 217, 196);
//set font arial, bold, 14pt
$pdf->SetFont('Arial','B',14);
//Cell(width, height , text , border , end line , [align] );
$pdf->Cell(10, 10, '',1,0);
$pdf->Cell(160 ,10,'Mohan Mutha Exports Pvt Ltd.',1,1,'C',true);
    

$pdf->SetFont('Arial','B',10);
$pdf->Cell(170 ,8,'Customer Data Form',1,1,'C',true);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,5,'Format No.:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(40 ,5,'SALES/FMT/015',1,0,'C');
$pdf->SetFont('Arial','B',8);
$pdf->Cell(40 ,5,'Date:',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(50 ,5,$cdate,1,1,'C');//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,15,'Customer Name (Registered Name)',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,15,$cname,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,5,'Group Companies to be Linked',1,0,'L',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,5,$cgroup,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,25,'Contact Address',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,25,$caddress,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,10,'Key Person ( Decision Maker )',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,10,$cpname,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Designation',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cdes,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Direct Telephone Number',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cpnumber,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Mobile Phone Number',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cmnumber,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Email ID',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cemail,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Website',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$curl,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Dischage Port',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cdport,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,6,'Final Destination',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,6,$cfinald,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,10,'Bank Details',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,10,$cbank,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,10,'Payment Tearms',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,10,$cpaym,1,1,'C');

$pdf->SetFont('Arial','B',8);
$pdf->Cell(170 ,5,'',1,1);//end of line

$pdf->SetFont('Arial','B',8);
$pdf->Cell(60 ,10,'Products',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(110 ,10,$cproduct,1,1,'C');

    
}

if(!empty($_GET['orid'])){
    $orid = $_GET['orid'];
    if(!empty($orid)){
        $reve  = "SELECT * FROM orders WHERE randid = $orid";
        $reve = $db->query($reve);
        $rev = $reve->fetch_object();
        $revi = $rev->revi;
    }
    $enid = $_GET['enid'];
    $enid = sprintf("%04d", $enid);
//A4 width 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm
require ('tcpdf/tcpdf.php');
$pdf = new TCPDF('l','mm','A4');
$pdf->SetMargins(8,10,0);
$pdf->AddPage();
$pdf->SetTitle("Order Pricing Sheet  $orid",false);
    

    
$pdf->Image("eformlogo.png",8,10,10,0);
$pdf->SetFillColor(221, 217, 196);
//set font arial, bold, 14pt
$pdf->SetFont('Times','B',14);
//Cell(width, height , text , border , end line , [align] );
$pdf->Cell(10, 10, '',1,0);
$pdf->Cell(271.1 ,10,'Mohan Mutha Exports Pvt Ltd.',1,1,'C',true);
$pdf->SetFont('Times','B',9);
$pdf->Cell(60 ,5,'Format No: SALES/FMT/017',1,0,'L');
$pdf->SetFont('Times','B',9);
$pdf->Cell(221.1 ,5,'Enquiry Pricing Sheet',1,1,'C', true);   
$pdf->SetFont('Times','B',7);
$pdf->Cell(46 ,5,"Enquiry No: MME/$year-$nyear/".(empty($revi) ? $enid : "$enid/R$revi"),1,0,'L');
$pdf->SetFont('Times','B',9);
$pdf->Cell(49 ,5,'Sales Pricing',1,0,'C',true);
$pdf->Cell(1.1 ,5,'',1,0,'C',true);

$pdf->SetFont('Times','B',9);
$pdf->Cell(185 ,5,'Purchase Pricing',1,1,'C', true);

$pdf->SetFont('Times','B',8);
    $pdf->MultiCell(10, 12, 'S.No', 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(36, 12, 'Item Description' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(11.5, 12, 'Qty' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(11.5, 12, 'UOM ' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12.5, 12, 'Rate / UOM ' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(13.5, 12, 'Total Amount ' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(1.1, 12, '', 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Cost 1', 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Weight / Pcs ' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Cost 2 ' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(15, 12, 'Packaging', 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(13.5,12, 'Handling' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Local Frt' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(13, 12, 'Other Charges' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Conv. Fact' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'USD Price' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'USD Total' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Sea / Air Frt' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Insurance' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(12, 12, 'Profit value' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(13, 12, 'Other Charges' , 1, 'C', 1, 0, '', '', true);
    $pdf->MultiCell(10.5, 12, 'CIF' , 1, 'C', 1, 1, '', '', true);
    /*
$pdf->Cell(20, 20, '',1,0,'C',true);
$pdf->Cell(35 ,20,'Item Description',1,0,'C',true);
$pdf->Cell(10.5 ,20,"QTY",1,0,'C',true);
$pdf->Cell(10.5 ,20,'UOM',1,0,'C',true);
$pdf->Cell(11.5 ,20,'R/Unit',1,0,'C',true);
$pdf->Cell(12.5 ,20,'T-Amt',1,0,'C',true);
$pdf->Cell(1.1 ,20,'',1,0,'C',true);
$pdf->Cell(12 ,20,'Cost 1',1,0,'C',true);
$pdf->Cell(12 ,20,'Wt / Pc',1,0,'C',true);
$pdf->Cell(12 ,20,'Cost 2',1,0,'C',true);
$pdf->Cell(12 ,20,'Pck Cst',1,0,'C',true);
$pdf->Cell(12 ,20,'Han-Ch',1,0,'C',true);
$pdf->Cell(12 ,20,'L Frt',1,0,'C',true);
$pdf->Cell(12 ,20,'Ot-Ch',1,0,'C',true);
$pdf->Cell(12 ,20,'CONV',1,0,'C',true);
$pdf->Cell(12 ,20,'UNIT PX',1,0,'C',true);
$pdf->Cell(12 ,20,'S frt',1,0,'C',true);
$pdf->Cell(12 ,20,'Ins',1,0,'C',true);
$pdf->Cell(12 ,20,'Pt Value',1,0,'C',true);
$pdf->Cell(12 ,20,'Ot-Ch',1,0,'C',true);
$pdf->Cell(12 ,20,'CIF',1,0,'C',true);
$pdf->Cell(12 ,20,'Final PX',1,1,'C',true);
    
*/
   
    if(!empty($orid)){
        $cuquery = "SELECT * FROM orders WHERE randid = $orid";
    $cuquery = $db->query($cuquery);
        $grand_total = 0;
        $grand_usdt = 0;
while($c = $cuquery->fetch_object()){ 
    
    $h = 7;
    $cncount = $c->pname;
    $cnc1 = strlen($cncount);
    $cndes = $c->des;
    $cnc2 = strlen($cndes);
    $cnc = $cnc1 + $cnc2;
    if($cnc > 27){
        $sum = $cnc/30;

      $sum1 = $sum * 2.9;
$h = $h + $sum1;

    }
    
    $grand_total += $c->total;
    $total = number_format($c->total,2);
    if(empty($c->rate)){
        $rate = 0;
    }else{
    $rate = number_format($c->rate,2);
    }
    if(empty($c->usdt)){
        $grand_usdt += 0;
    }else{
        $grand_usdt += $c->usdt;
    }
     if(empty($c->usdt)){
         $usdt = 0;
     }else{
         $usdt = number_format($c->usdt,2);
     }
    
    $pdf->SetFont('Times','B',6);
$pdf->MultiCell(10, $h, $c->slno, 1, 'L', 0, '', '');
$pdf->MultiCell(36, $h, "$c->pname \n $c->des", 1, 'L', 0, '', '');
//$pdf->Cell(35 ,5,"$c->pname",0,0,'C');
$pdf->Cell(11.5 ,$h,$c->qty,1,0,'C');
$pdf->Cell(11.5 ,$h,$c->uom,1,0,'C');
$pdf->Cell(12.5 ,$h,(!empty($rate)?'$'.$rate:''),1,0,'C');
$pdf->Cell(13.5 ,$h,(!empty($total)?'$ '.$total:''),1,0,'C');
  //money_format('%i', $c->total) 
   
$pdf->Cell(1.1 ,$h,'',1,0,'C',true);
    
$pdf->Cell(12 ,$h,$c->cost1,1,0,'C');
$pdf->Cell(12 ,$h,$c->wepc,1,0,'C');
$pdf->Cell(12 ,$h,$c->cost2,1,0,'C');
$pdf->Cell(15 ,$h,$c->pac,1,0,'C');
$pdf->Cell(13.5 ,$h,$c->hand,1,0,'C');
$pdf->Cell(12 ,$h,$c->lfrt,1,0,'C');
$pdf->Cell(13 ,$h,$c->otrchr,1,0,'C');
$pdf->Cell(12 ,$h,$c->conv,1,0,'C');
$pdf->Cell(12 ,$h,$c->usdprice,1,0,'C');
$pdf->Cell(12 ,$h,(!empty($rate)?'$ '.$usdt:''),1,0,'C');
$pdf->Cell(12 ,$h,$c->sftr,1,0,'C');
$pdf->Cell(12 ,$h,$c->ins,1,0,'C');
$pdf->Cell(12 ,$h,$c->pftv,1,0,'C');
$pdf->Cell(13 ,$h,$c->usdoc,1,0,'C');
$pdf->Cell(10.5 ,$h,$c->cif,1,1,'C');
//$pdf->Cell(.1 ,5,"",1,1,'C');
//$pdf->Cell(20,5,'',0,0);
    
//$pdf->Cell(35 ,5,"$c->des",1,1,'C');
        }
        $pdf->Ln(1);
        if(!empty($enid)){
           $eq = "SELECT * FROM enquiry WHERE id = $enid";
    $eq = $db->query($eq);
$eq = $eq->fetch_object();
    $id = $eq->id;
            if(!empty($id)){
                $doe = "SELECT * FROM parent WHERE eid = $id";
                $doe = $db->query($doe);
                $doe = $doe->fetch_object();
                $doe = strtotime($doe->created);
                $doe = date("d/m/20y",$doe);
            }
    $name = $eq->name;
    if(!empty($name));{
                                    $name = "SELECT * FROM customers WHERE id = $name";
                                    $name = $db->query($name);
                                    $name = $name->fetch_object();
                                    $name = $name->cname;
                                }
            
    $moe = $eq->moe;
    $pn = $eq->pn;
    $pd = $eq->pd;
    $pq = $eq->pq;
    $qr = $eq->qr;
    $ep = $eq->ep;
    $ds = $eq->ds;
    $pr = $eq->pr;
    $lr = $eq->lr;
    $lb = $eq->lb;
    $otr = $eq->otr;
    $ad = $eq->ad;
    $cfeas = $eq->cfeas;
    $pfeas = $eq->pfeas;
    $lfeas = $eq->lfeas;
    $sc = $eq->sc;
    $bdm = $eq->bdm;
    $director = $eq->director;
            if(!empty($director)){
                if($director == 1){
                    $dir= "RAMESH KUMAR MUTHA";
                }
                if($director == 2){
                    $dir= "TEJRAJ JAIN";
                }
                if($director == 3){
                    $dir= "VIKAS JAIN";
                }
                if($director == 4){
                    $dir= "KAMLESH JAIN";
                }
            }
            $en = "SELECT * FROM parent WHERE eid=$enid";
            $en = $db->query($en);
$en = $en->fetch_object();
            $note=$en->note;
        }
$pdf->SetFont('Times','B',8);
//$total = "SELECT SUM(total) FROM orders WHERE randid = $orid";
        //$total = $db->query($total);
        $grand_total = number_format($grand_total,2);
$pdf->Cell(95 ,5,'Selling Price Grand Total :  $ '.$grand_total,1,0,'C', true);
        $pdf->Cell(1.1 ,5,'',1,0,'C',true);
        $grand_usdt = number_format($grand_usdt,2);
$pdf->Cell(185 ,5,'Buying Price Grand Total :  $ '.$grand_usdt,1,1,'C', true);
$pdf->Cell(76 ,5,'Prepared By',1,0,'C',true);
$pdf->Cell(59.9 ,5,'Approved By',1,0,'C',true);
$pdf->Cell(34.7 ,5,'Date',1,0,'C',true);
$pdf->Cell(110.5 ,5,'JUSTIFICATION REMARKS',1,1,'C',true);
  
$pdf->Cell(16 ,5,'Name:',1,0,'L',true);
$pdf->Cell(60 ,5,$sc,1,0,'C',true);
$pdf->Cell(16 ,5,'Name:',1,0,'L',true);
$pdf->Cell(43.9 ,5,$dir,1,0,'C',true);
$pdf->Cell(34.7 ,20,$doe,1,0,'C');
$pdf->Cell(110.5 ,20,$note,1,0,'C');
$pdf->Cell(0,5,'',0,1);
  
$pdf->Cell(16 ,5,'Design:',1,0,'L',true);
$pdf->Cell(60 ,5,'Sales Co-Ordinator',1,0,'C',true);
$pdf->Cell(16 ,5,'Design:',1,0,'L',true);
$pdf->Cell(43.9 ,5,$bdm,1,0,'C',true);
$pdf->Cell(139.2 ,5,'',0,1);
  
$pdf->Cell(16 ,10,'Signature:',1,0,'L',true);
$pdf->Cell(60 ,10,'',1,0,'C');
$pdf->Cell(16 ,10,'Signature:',1,0,'L',true);
$pdf->Cell(43.9 ,10,'',1,0,'C');
$pdf->Cell(139.2 ,5,'',0,1);
        }
    $pdf->Ln(10);
     
  /*$pdf->Cell(282 ,5,'Breif Definition',1,1,'C',true); 
  $pdf->Cell(47 ,5,'QTY -> Qty / MOQ',1,0,'C');  
  $pdf->Cell(47 ,5,'UOM -> UOM',1,0,'C');  
  $pdf->Cell(47 ,5,'R/Unit -> Rate Per Unit',1,0,'C');  
  $pdf->Cell(47 ,5,'T-Amt -> Total Amount',1,0,'C');  
  $pdf->Cell(47 ,5,'Cost 1 -> Cost 1',1,0,'C');  
  $pdf->Cell(47 ,5,'Wt / Pc -> Weight or Pieces',1,1,'C'); 
  $pdf->Cell(47 ,5,'Cost 2 -> Cost 2',1,0,'C');  
  $pdf->Cell(47 ,5,'Pck Cst -> Packaging Cost',1,0,'C');  
  $pdf->Cell(47 ,5,'L Frt -> Local Freight Charge',1,0,'C');  
  $pdf->Cell(47 ,5,'Han-Ch -> Handling Charges',1,0,'C');  
  $pdf->Cell(47 ,5,'Ot Ch -> Other Charges',1,0,'C');  
  $pdf->Cell(47 ,5,'CONV -> Conversion fact',1,1,'C'); 
  $pdf->Cell(47 ,5,'UNIT PX -> Unit Price',1,0,'C');  
  $pdf->Cell(47 ,5,'S frt -> Sea Freight Charge',1,0,'C');  
  $pdf->Cell(47 ,5,'Ins -> Insurance',1,0,'C');  
  $pdf->Cell(47 ,5,'Pt Value -> Profit Value:',1,0,'C');  
  $pdf->Cell(47 ,5,'Ot-Ch -> Other Charges',1,0,'C');  
  $pdf->Cell(47 ,5,'CIF -> CIF',1,1,'C');  
  $pdf->Cell(47 ,5,'Final PX -> CIF Final Round Off',1,1,'C'); 
  */
    
}

$pdf->Output();


?>