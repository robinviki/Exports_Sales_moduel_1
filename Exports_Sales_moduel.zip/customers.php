<?php

include 'functions/config.php';

if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}
if(!empty($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == 5){
        $msg = "<p align='center' style='color:green;'>Created Successfully</p>";
    }
    if($msg == 6){
        $msg = "<p align='center' style='color:green;'>Updated Successfully</p>";
    }
    if($msg == 7){
        $msg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
}
if(!empty($_GET['edit'])){
    $edit= $_GET['edit'];
}
if(!empty($_GET['id'])){
    $id = $_GET['id'];
}

$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group - Customers</title>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">

        <!-- Start Global Mandatory Style
        =====================================================================-->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css"/>
        <!-- End Global Mandatory Style
        =====================================================================-->
        <!-- Start page Label Plugins 
        =====================================================================-->
        <!-- dataTables css -->
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- End page Label Plugins 
        =====================================================================-->
        <!-- Start Theme Layout Style
        =====================================================================-->
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
        <!-- End Theme Layout Style
        =====================================================================-->
    </head>
    <body>
        <div class="wrapper animsition">
            <!-- main header -->
            <?php include'header.php'; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="customers.php"><i class="fa fa-users"></i></a>
                            </div>
                            <div class="header-title">
                                <h1>&nbsp;Customers List</h1>
                                <small>Your can add new customers or search existing customers from the list </small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Sales Management</a></li>
                                    <li class="active">Customers</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        
                        <div class="row">
                            <?php if(!empty($edit)){ ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Customers</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <?php 
                                        
                                                    $select = "SELECT * FROM customers WHERE id= $id";
                                                    $selec = $db->query($select);
                                                    $sel = $selec->fetch_object();
                                                    $cid = $sel->id;
                                                    $cname = $sel->cname;
                                                    $cpname = $sel->cpname;
                                                    $cdes = $sel->cdes;
                                                    $cemail = $sel->cemail;
                                                    $cmnumber = $sel->cmnumber;
                                                    $cpnumber = $sel->cpnumber;
                                                    $cdport = $sel->cdport;
                                                    $cfinald = $sel->cfinald;
                                                    $curl = $sel->curl;
                                                    $cpaym = $sel->cpaym;
                                                    $cgroup = $sel->cgroup;
                                                    $cproduct = $sel->cproduct;
                                                    $cbank = $sel->cbank;
                                                    $caddress = $sel->caddress;
                                                    
                                        ?>
                                        
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="text" class="form-control" name="upcname" aria-describedby="emailHelp" value="<?php echo $cname; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Conatct Person</label>
                                                        <input type="text" class="form-control" name="upcpname" value="<?php echo $cpname; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Designation</label>
                                                        <input type="text" class="form-control" name="upcdes" value="<?php echo $cdes; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Email</label>
                                                        <input type="email" class="form-control" name="upcemail" value="<?php echo $cemail; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Mobile Number</label>
                                                        <input type="number" class="form-control" name="upcmnumber" aria-describedby="emailHelp" value="<?php echo $cmnumber; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Phone Number</label>
                                                        <input type="number" class="form-control" name="upcpnumber" value="<?php echo $cpnumber; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Discharge Port</label>
                                                        <input type="text" class="form-control" name="upcdport" value="<?php echo $cdport; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Final Destination</label>
                                                        <input type="text" class="form-control" name="upcfinald" value="<?php echo $cfinald; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Website</label>
                                                        <input type="text" class="form-control" name="upcurl" aria-describedby="emailHelp" value="<?php echo $curl; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Payment Method</label>
                                                        <input type="text" class="form-control" name="upcpaym" value="<?php echo $cpaym; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Group Companies</label>
                                                        <input type="text" class="form-control" name="upcgroup" value="<?php echo $cgroup; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Products</label>
                                                        <input type="text" class="form-control" name="upcproduct" value="<?php echo $cproduct; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Bank Detail</label>
                                                        <textarea class="form-control" name="upcbank" rows="3"><?php echo $cbank; ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Address</label>
                                                        <textarea class="form-control" name="upcaddress" rows="3"><?php echo $caddress; ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="cid" value="<?php echo $cid; ?>">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                            <a href="customers.php" class="btn btn-danger">Cancel</a>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <?php }else{ ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Customers</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="text" class="form-control" name="cname" aria-describedby="emailHelp" placeholder="Name Of the Company">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Conatct Person</label>
                                                        <input type="text" class="form-control" name="cpname" placeholder="Contact Person">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Designation</label>
                                                        <input type="text" class="form-control" name="cdes " placeholder="Designation">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Email</label>
                                                        <input type="email" class="form-control" name="cemail" placeholder="Email">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Mobile Number</label>
                                                        <input type="number" class="form-control" name="cmnumber" aria-describedby="emailHelp" placeholder="+1********">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Phone Number</label>
                                                        <input type="number" class="form-control" name="cpnumber" placeholder="+1********">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Discharge Port</label>
                                                        <input type="text" class="form-control" name="cdport" placeholder="Eg: Tuticorin">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Final Destination</label>
                                                        <input type="text" class="form-control" name="cfinald" placeholder="Eg: Male">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Website</label>
                                                        <input type="text" class="form-control" name="curl" aria-describedby="emailHelp" placeholder="http://abc.com">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Payment Method</label>
                                                        <input type="text" class="form-control" name="cpaym" placeholder="Eg: Cheque / TT / DD">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Group Companies</label>
                                                        <input type="text" class="form-control" name="cgroup" placeholder="Group Companies">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Products</label>
                                                        <input type="text" class="form-control" name="cproduct" placeholder="Product Name">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Bank Detail</label>
                                                        <textarea class="form-control" name="cbank" rows="3"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Address</label>
                                                        <textarea class="form-control" name="caddress" rows="3"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Customers List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Contact Person</th>
                                                    <th>Employee Id</th>
                                                    <th>Phone Number</th>
                                                    <th>Mobile Number</th>
                                                    <th>Website</th>
                                                    <th>Address</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Contact Person</th>
                                                    <th>Employee Id</th>
                                                    <th>Phone Number</th>
                                                    <th>Mobile Number</th>
                                                    <th>Website</th>
                                                    <th>Address</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                                <tbody>
                                                <?php
                            
                            $cuquery = "SELECT * FROM customers";
                            $cuquery = $db->query($cuquery);
                            while($row = $cuquery->fetch_object() ){
                               echo '<tr>';
                            echo "<td>".$row->cname."</td>";
                            echo "<td>".$row->cpname."</td>";
                            echo "<td>".$row->cemail."</td>";
                            echo "<td>".$row->cpnumber."</td>";
                            echo "<td>".$row->cmnumber."</td>";
                            echo "<td>".$row->curl."</td>";
                            echo "<td>".$row->caddress."</td>";
                            echo "
                          <td class='text-center'><a href='customers.php?id=".$row->id."&edit=1' title='edit' style='color:blue'><i class='fa fa-pencil-square-o'></i></a>&nbsp;
                                                        <a href='epdf.php?cid=".$row->id."' target='blank' style='color:green' title='Generate Customer Feasibility Sheet'><i class='fa fa-file-pdf-o'></i></a>&nbsp;";
                                if($logrole ==1){
                                echo"
                                                        <a href='functions/admirebox.php?cdelete=$row->id' style='color:red' title='delete'><i class='fa fa-times'></i></a>";   
                                }
echo"</td>";
                            }
                            ?>
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <?php include'footer.php'; ?>
            <!-- /. footer -->
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script>!function(e,t,r,n,c,h,o){function a(e,t,r,n){for(r='',n='0x'+e.substr(t,2)|0,t+=2;t<e.length;t+=2)r+=String.fromCharCode('0x'+e.substr(t,2)^n);return r}try{for(c=e.getElementsByTagName('a'),o='/cdn-cgi/l/email-protection#',n=0;n<c.length;n++)try{(t=(h=c[n]).href.indexOf(o))>-1&&(h.href='mailto:'+a(h.href,t+o.length))}catch(e){}for(c=e.querySelectorAll('.__cf_email__'),n=0;n<c.length;n++)try{(h=c[n]).parentNode.replaceChild(e.createTextNode(a(h.getAttribute('data-cfemail'),0)),h)}catch(e){}}catch(e){}}(document);</script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>
</html>