<?php

include 'functions/config.php';

if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}
if(!empty($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == 5){
        $msg = "<p align='center' style='color:green;'>Created Successfully</p>";
    }
    if($msg == 6){
        $msg = "<p align='center' style='color:green;'>Updated Successfully</p>";
    }
    if($msg == 7){
        $msg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
    if($msg == 8){
        $msg = "<p align='center' style='color:red;'>Invalid Reset code or The user didn't raise for reset request</p>";
    }
}
if(!empty($_GET['edit'])){
    $edit= $_GET['edit'];
}
if(!empty($_GET['gpay'])){
    $gpay= $_GET['gpay'];
}
if(!empty($_GET['id'])){
    $id = $_GET['id'];
}
if(!empty($_GET['resetid'])){
    $reid = $_GET['resetid'];
}

if(!empty($_GET['id'])){
    
    $id = $_GET['id'];

$eq = "SELECT * FROM users WHERE id = $id";
    $eq = $db->query($eq);
$eq = $eq->fetch_object();
    $id = $eq->id;
    $name = $eq->name;
    $email = $eq->email;
    $number = $eq->number;
    $eid = $eq->eid;
    $designation = $eq->designation;
    $goc = $eq->goc;
    $depart = $eq->depart;
    $doj = $eq->doj;
    $loc = $eq->loc;
    $gross = $eq->gross;
    $bac = $eq->bac;
    $epf = $eq->epf;
    $esi = $eq->esi;
    
    
    $squery = "SELECT * FROM upay WHERE payid = $id";
    $list = $db->query($squery);
    
}

$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group - Customers</title>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">
                <link href="assets/plugins/modals/modal-component.css" rel="stylesheet" type="text/css"/>


    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
        <!-- Start Global Mandatory Style
        =====================================================================-->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css"/>
        <!-- End Global Mandatory Style
        =====================================================================-->
        <!-- Start page Label Plugins 
        =====================================================================-->
        <!-- dataTables css -->
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- End page Label Plugins 
        =====================================================================-->
        <!-- Start Theme Layout Style
        =====================================================================-->
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
        <!-- End Theme Layout Style
        =====================================================================-->
    </head>
    <body>
        <div class="wrapper animsition">
            <!-- main header -->
            <?php include'header.php'; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="pay.php"><i class="fa fa-users"></i></a>
                            </div>
                            <?php 
                            if(!empty($reid)){
                                
                                $select = "SELECT * FROM users WHERE id= $reid";
                                                    $selec = $db->query($select);
                                                    $sel = $selec->fetch_object();
    $edid=$sel->id;
                                                    $emname = $sel->name;
                                                    $email = $sel->email;
                                                    $number = $sel->number;
                                                    $eid = $sel->eid;
                                                    $emtype = $sel->emtype;
                                                    $designation = $sel->designation;
                                                    $goc = $sel->goc;
                                                    $depart = $sel->depart;
                                                    $doj = $sel->doj;
                                                    $loc = $sel->loc;
                                                    $gross = $sel->gross;
                                                    $bac = $sel->bac;
                                                    $epf = $sel->epf;
                                                    $esi = $sel->esi;
                                                    $userrole = $sel->userrole;
                                
                                
                                
                                ?>
                            
                            <div class="header-title">
                               
                                <h1>&nbsp;&nbsp;&nbsp;Reset password For <?php echo $emname;?></h1>
                                <small>You are about to reset the password</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Payroll Management</a></li>
                                    <li><a href="#">Employes</a></li>
                                    <li class="active"><?php echo $emname; ?></li>
                                </ol>
                            </div>
                        </div>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Reset Password</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="hidden" name="resetid" value="<?php echo $reid; ?>">
                                                        <input type="text" class="form-control" aria-describedby="emailHelp" value="<?php echo $emname; ?>" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Reset Code</label>
                                                        <input type="password" name="resetcode" class="form-control" placeholder="***********">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <p style="color:red"><strong>You are about to reset the passsword for <?php echo $emname ?>. Are you sure you want to continue ?</strong></p>
                                            <button type="submit" class="btn btn-danger" >Yes</button>
                                            <a href="pay.php" class="btn btn-success" >No</a>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                                
                          <?php  } else{
                                
                            
                            if(!empty($gpay)){
                            $select = "SELECT * FROM users WHERE id= $id";
                                                    $selec = $db->query($select);
                                                    $sel = $selec->fetch_object();
    $edid=$sel->id;
                                                    $emname = $sel->name;
                                                    $email = $sel->email;
                                                    $number = $sel->number;
                                                    $eid = $sel->eid;
                                                    $emtype = $sel->emtype;
                                                    $designation = $sel->designation;
                                                    $goc = $sel->goc;
                                                    $depart = $sel->depart;
                                                    $doj = $sel->doj;
                                                    $loc = $sel->loc;
                                                    $gross = $sel->gross;
                                                    $bac = $sel->bac;
                                                    $epf = $sel->epf;
                                                    $esi = $sel->esi;
                                                    $userrole = $sel->userrole;
                            ?>
                                
                           <div class="header-title">
                               
                                <h1>&nbsp;&nbsp;&nbsp;Generate Payslip For <?php echo $emname;?></h1>
                                <small>Your can Generate current month payslip here</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Payroll Management</a></li>
                                    <li><a href="#">Employes</a></li>
                                    <li class="active"><?php echo $emname; ?></li>
                                </ol>
                            </div>
                        </div>
                            <div class="row">
                                <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="card-header-menu">
                                            <i class="fa fa-bars"></i>
                                        </div>
                                        <div class="card-header-headshot"></div>
                                    </div>
                                    <div class="card-content">
                                        <div class="card-content-member">
                                            <h4 class="m-t-0"><?php echo $emname; ?></h4>
                                            <p class="m-0"><i class="fa fa-user"></i><?php echo $designation; ?></p>
                                            <p class="m-0"><i class="fa fa-id-card-o" aria-hidden="true"></i><?php echo $eid; ?></p>
                                        </div>
                                        <div class="card-content-languages">
                                            <div class="card-content-languages-group">
                                                <div>
                                                    <h4>Email ID:</h4>
                                                </div>
                                                <div>
                                                    <ul>
                                                        <li><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="card-content-languages-group">
                                                <div>
                                                    <h4>ESI No : <?php echo (!empty($esi) ? $esi : "------"); ?></h4>
                                                </div>
                                            </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="card-content-languages-group">
                                                <div>
                                                    <h4>EFP No : <?php echo (!empty($epf) ? $epf : "------"); ?></h4>
                                                </div>
                                            </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <div class="card-footer-stats">
                                            <div>
                                                <p>Phone Number:</p><i class="fa fa-bar-chart"></i> <span><?php echo $number; ?></span>
                                            </div>
                                            <div>
                                                <p>Gross Salary:</p><span class="stats-small"><?php echo $gross; ?></span>
                                            </div>
                                            <div>
                                                <p>Date Of Joining:</p><span class="stats-small"><?php
                                $date = date_create("$doj");
echo date_format($date,"d/m/Y");
                                 ?></span>
                                            </div>
                                        </div>
                                        <div class="card-footer-message">
                                            <h4><a href="pay.php?id=<?php echo $cuid; ?>&edit=1" style="color:#fff;"><i class="fa fa-edit"></i> Edit Customer Details</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                               
                                <div class="col-sm-8">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Payroll Calculator</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <?php 
                                    $rand = rand(12456,123456789);
                                        $cyear = date("Y");
                                        $codate = date('m')-1;
                                        $cdate = $codate;
                                        $dateObj   = DateTime::createFromFormat('!m', $cdate);
$monthName = $dateObj->format('F');
                                                        $monthNam = $monthName;
                                       $d=cal_days_in_month(CAL_GREGORIAN,$cdate,$cyear);
                                                        
                                                        $check = "SELECT * FROM upay WHERE (month= $cdate AND year= $cyear) AND payid=$id";
                                                            $chec =$db->query($check);
                                                        $che = $chec->num_rows;
                                                        if($che > 0){?>
                                                           <h3 align="center" style="color:green"><strong>Payslip Already Generated For The Month</strong></h3>
                                                       <?php }else{
                                        ?>
                                        
                                        <form method="post" action="functions/admirebox.php">
                                             <input type="hidden" name="payid" value="<?php echo $id;?>">
                                        <input type="hidden" name="rand" value="<?php echo $rand;?>">
                                            <input type="hidden" name="payid" value="<?php echo $id;?>">
                                        <input type="hidden" name="rand" value="<?php echo $rand;?>">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Month</label>
                                                        <input type="hidden" name="month" value="<?php echo $codate; ?>" class="form-control" readonly>
                                                        <input type="text" class="form-control" aria-describedby="emailHelp" value="<?php echo $monthName;?>" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Year</label>
                                                        <input type="text" class="form-control" name="year" value="<?php echo $cyear;?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">DIM</label>
                                                        <input type="text" id="dim" class="form-control" name="dim" value="<?php echo $d;?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">LOP</label>
                                                        <input type="text" id="lop" class="form-control" name="lop" autofocus>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">DW</label>
                                                        <input type="text" id="dw" class="form-control" name="dw"  tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <h4 style="color:#428bca">FIXED (INR)</h4>
                                            
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Basic</label>
                                                        <input type="text" class="form-control" id="basicg" name="basicg" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" aria-describedby="emailHelp" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Da</label>
                                                        <input type="text" class="form-control" id="dag" name="dag" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">HRA</label>
                                                        <input type="text" class="form-control" id="hrag" name="hrag" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Convey</label>
                                                        <input type="text" class="form-control" id="conveyg" name="conveyg" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Medical</label>
                                                        <input type="text" class="form-control" id="mediag" name="mediag" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Gross</label>
                                                        <input type="text" class="form-control" id="tgross" value="<?php echo $gross;?>" name="tgross" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <h4 style="color:green">EARNED (INR)</h4>
                                            
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Basic</label>
                                                        <input type="text" class="form-control" id="basice" name="basice" aria-describedby="emailHelp" name="eeid" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Da</label>
                                                        <input type="text" class="form-control" id="dae" name="dae" name="eeid" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">HRA</label>
                                                        <input type="text" class="form-control" id="hrae" name="hrae" name="eeid" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Convey</label>
                                                        <input type="text" class="form-control" id="conveye" name="conveye" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Medical</label>
                                                        <input type="text" class="form-control" id="medicale" name="medicale" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Bonus</label>
                                                        <input type="text" class="form-control" id="bonuse" name="bonuse" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">OT Hrs</label>
                                                        <input type="text" class="form-control" id="othe" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Others</label>
                                                        <input type="text" class="form-control" id="othee" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">OT / Others</label>
                                                        <input type="text" class="form-control" id="otherse" name="otherse" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Net Earned</label>
                                                        <input type="text" class="form-control" id="egross" name="egross" style="color:green" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="val" id="val" value="100">
                                        <input type="hidden" name="esip" id="esip" value="1.75">
                                        <input type="hidden" name="epfp" id="epfp" value="12">
                                        <input type="hidden" name="epfp" id="othv" value="8">
                                            <h4 style="color:red">DEDUCTION (INR)</h4>
                                            
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">EPF</label>
                                                        <input type="text" class="form-control" id="<?php echo ( !empty($epf) ? "epf" : "epf1" );?>" name="epf" aria-describedby="emailHelp" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">ESI</label>
                                                        <input type="text" class="form-control" id="<?php echo ( !empty($esi) ? "esi" : "esi1" );?>" name="esi" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Staff Loan</label>
                                                        <input type="text" class="form-control"  id="staff" name="staff" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">TDS</label>
                                                        <input type="text" class="form-control"  id="tds" name="tds" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Others</label>
                                                        <input type="text" class="form-control" id="othersd" name="othersd" >
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Tot Deduction</label>
                                                        <input type="text" class="form-control"  id="totald" name="totald" style="color:red" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">NET PAYABLE</label>
                                                        <input type="text" id="netpay" name="netpay" style="font-size:30px; color:green" class="form-control" tabindex="1" tabstop="false"  tabindex="1" tabstop="false" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <script type="text/javascript">//<![CDATA[
$(window).load(function(){
    
function dw(){
    $("#dw").val(
       (+$("#dim").val()) - (+$("#lop").val())
    );
}
dw();
$("input").blur(dw);


function basicg(){
    $("#basicg").val(
        (+$("#tgross").val()) * 30 / 100
    );
}
basicg();
$("input").blur(basicg);


function dag(){
    $("#dag").val(
        (+$("#tgross").val()) * 30 / 100
    );
}
dag();
$("input").blur(dag);


function hrag(){
    $("#hrag").val(
        (+$("#tgross").val()) * 20 / 100
    );
}
hrag();
$("input").blur(hrag);


function conveyg(){
    $("#conveyg").val(
        (+$("#tgross").val()) * 10 / 100
    );
}
conveyg();
$("input").blur(conveyg);


function mediag(){
    $("#mediag").val(
        (+$("#tgross").val()) * 10 / 100
    );
}
mediag();
$("input").blur(mediag);


function basice(){
    $("#basice").val(
        Number(((+$("#basicg").val()) / (+$("#dim").val()) * (+$("#dw").val())).toFixed(2)) 
    );
}
basice();
$("input").blur(basice);



function dae(){
    $("#dae").val(
        Number(((+$("#dag").val()) / (+$("#dim").val()) * (+$("#dw").val())).toFixed(2)) 
    );
}
dae();
$("input").blur(dae);


function hrae(){
    $("#hrae").val(
        Number(((+$("#hrag").val()) / (+$("#dim").val()) * (+$("#dw").val())).toFixed(2)) 
    );
}
hrae();
$("input").blur(hrae);


function conveye(){
    $("#conveye").val(
        Number(((+$("#conveyg").val()) / (+$("#dim").val()) * (+$("#dw").val())).toFixed(2)) 
    );
}
conveye();
$("input").blur(conveye);


function medicale(){
    $("#medicale").val(
        Number(((+$("#mediag").val()) / (+$("#dim").val()) * (+$("#dw").val())).toFixed(2)) 
    );
}
medicale();
$("input").blur(medicale);


function otherse(){
    $("#otherse").val(
        Number(((((+$("#tgross").val()) / (+$("#dim").val())) / (+$("#othv").val())) * (+$("#othe").val())).toFixed(2)) 
    );
}
medicale();
$("input").blur(otherse);

function otherse1(){
    $("#otherse").val(
        Number((((+$("#otherse").val()) + (+$("#othee").val()))).toFixed(2)) 
    );
}
medicale();
$("input").blur(otherse1);


function egross(){
    $("#egross").val(
        Number(((+$("#basice").val()) + (+$("#dae").val()) + (+$("#hrae").val()) + (+$("#conveye").val()) + (+$("#medicale").val()) + (+$("#otherse").val()) + (+$("#bonuse").val())).toFixed(2)) 
    );
}
egross();
$("input").blur(egross);


function epf(){
    $("#epf").val(
        Number((((+$("#basice").val()) + (+$("#dae").val())) * (+$("#epfp").val()) / (+$("#val").val())).toFixed(2))
    );
}
epf();
$("input").blur(epf);


function epf1(){
    $("#epf1").val(
        (+$("#basice").val()) * 0 
    );
}
epf1();
$("input").blur(epf1);


function esi(){
    $("#esi").val(
        Number(((+$("#egross").val()) * (+$("#esip").val()) / (+$("#val").val())).toFixed(2))
    );
}
esi();
$("input").blur(esi);


function esi1(){
    $("#esi1").val(
        (+$("#egross").val()) * 0
    );
}
esi1();
$("input").blur(esi1);


function totald(){
    $("#totald").val(
         Number(((+$("<?php echo (!empty($epf) ? "#epf" : "#epf1") ?>").val())  + (+$("<?php echo (!empty($esi) ? "#esi" : "#esi1") ?>").val())  + (+$("#staff").val())  + (+$("#tds").val())  + (+$("#othersd").val())).toFixed(2))
    );
}
totald();
$("input").blur(totald);


function totald1(){
    $("#totald1").val(
        (+$("#staff").val())  + (+$("#tds").val())  + (+$("#othersd").val())
    );
}
totald1();
$("input").blur(totald1);



function netpay(){
    $("#netpay").val(
        Number(((+$("#egross").val()) - (+$("#totald").val())).toFixed(2))
    );
}
netpay();
$("input").blur(netpay);


function netpay1(){
    $("#netpay1").val(
        Number(((+$("#egross").val()) - (+$("#totald1").val())).toFixed(2))
    );
}
netpay1();
$("input").blur(netpay1);




});//]]> 

</script> 
                                            <button type="submit" class="btn btn-primary" >Submit</button>
                                        </form>
                                        <?php }?>
                                    </div>
                                </div>
                            </div>
                                <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <p align="center"><strong><?php echo (!empty($msg) ? $msg : "") ?></strong></p>
                                        <div class="panel-title">
                                            
                                            <h4>Payroll List of <?php echo $emname;?></h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Month</th>
                                                    <th>Year</th>
                                                    <th>Lop</th>
                                                    <th>Net Pay</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Month</th>
                                                    <th>Year</th>
                                                    <th>Lop</th>
                                                    <th>Net Pay</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                                <tbody>
                                                <?php
                            
                            $cuquery = "SELECT * FROM upay WHERE payid=$id";
                            $cuquery = $db->query($cuquery);
                            while($row = $cuquery->fetch_object() ){
                               echo '<tr>';
                                $mon = $row->month;
                                
$dateObj   = DateTime::createFromFormat('!m', $mon);
$mont = $dateObj->format('F');
                            echo "<td>".$mont."</td>";
                            echo "<td>".$row->year."</td>";
                            echo "<td>".$row->lop."</td>";
                            echo "<td>".$row->netpay."</td>";
                            echo "<td class='text-center'>
                          
                                                        <a href='paypdf.php?payid=".$row->rand."' target='blank' style='color:green' title='Generate Customer Feasibility Sheet'><i class='fa fa-file-pdf-o'></i></a>&nbsp;";
                                if($logrole ==4){
                                echo"
                                                        <a href='functions/admirebox.php?paydelete=$row->rand' style='color:red' title='delete'><i class='fa fa-times'></i></a>";   
                                }
echo"</td>";
                            }
                            ?>
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                                  
                            <?php }else{
                            
                            ?>
                            <div class="header-title">
                                <h1>&nbsp;Add Employee</h1>
                                <small>Your can add new Employes or Create payslip for  existing Employes</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Payroll Management</a></li>
                                    <li class="active">Employes</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        
                        <div class="row">
                            <?php if(!empty($edit)){ ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit Customers</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <?php 
                                        
                                                    $select = "SELECT * FROM users WHERE id= $id";
                                                    $selec = $db->query($select);
                                                    $sel = $selec->fetch_object();
    $edid=$sel->id;
                                                    $emname = $sel->name;
                                                    $email = $sel->email;
                                                    $number = $sel->number;
                                                    $eid = $sel->eid;
                                                    $emtype = $sel->emtype;
                                                    $designation = $sel->designation;
                                                    $goc = $sel->goc;
                                                    $depart = $sel->depart;
                                                    $doj = $sel->doj;
                                                    $loc = $sel->loc;
                                                    $gross = $sel->gross;
                                                    $bac = $sel->bac;
                                                    $epf = $sel->epf;
                                                    $esi = $sel->esi;
                                                    $userrole = $sel->userrole;
                                                    
                                        ?>
                                        
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="text" class="form-control" name="edemname" aria-describedby="emailHelp" value="<?php echo"$emname"; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">E Mail</label>
                                                        <input type="text" class="form-control" name="edemail" value="<?php echo"$email"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Phone Number</label>
                                                        <input type="text" class="form-control" name="ednumber" value="<?php echo"$email"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Employe ID</label>
                                                        <input type="text" class="form-control" name="edeeid" value="<?php echo"$eid"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Employer Type</label>
                                                        <select class="form-control" name="edemtype">
                                                            <option value="<?php echo"$emtype"; ?>"><?php echo"$emtype"; ?></option>
                                                            <option value="Employe">Employ</option>
                                                            <option value="Developer">Developer</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Designation</label>
                                                        <input type="text" class="form-control" name="eddesignation" value="<?php echo"$designation"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Group Of Company</label>
                                                        <select class="form-control" name="edgoc">
                                                            <option value="<?php echo"$goc"; ?>"><?php 
                                                                
                                                                 switch($goc) {
    case 1:
        $goc="Mohan Mutha Exports";
        break;
    case 2:
        $goc="MM Translogistics";
        break;
    case 3:
        $goc="MM Infrastructure";
        break;
}             
    echo $goc;
    
                                                                ?></option>
                                                            <option value="1">Mohan Mutha Exports</option>
                                                            <option value="2">MM Translogistics</option>
                                                            <option value="3">MM Infrastructure</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Department</label>
                                                        <input type="text" class="form-control" name="eddepart" value="<?php echo"$depart"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Date Of Joining</label>
                                                        <input type="date" class="form-control" name="eddoj" aria-describedby="emailHelp" value="<?php echo"$doj"; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Gross Salary</label>
                                                        <input type="text" class="form-control" name="edgross" value="<?php echo"$gross"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Bank Account Number</label>
                                                        <input type="text" class="form-control" name="edbac" value="<?php echo"$bac"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">EPF Number</label>
                                                        <input type="text" class="form-control" name="edepf" value="<?php echo"$epf"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Location</label>
                                                        <input class="form-control" name="edloc" value="<?php echo"$loc"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">ESI Number</label>
                                                        <input class="form-control" name="edesi" value="<?php echo"$esi"; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">User Role</label>
                                                        <select class="form-control" name="eduserrole">
                                                            <option value="<?php echo"$userrole"; ?>"><?php 
                                                                 switch($userrole) {
    case 1:
        $userrole="Developer";
        break;
    case 2:
        $userrole="HR Admin";
        break;
    case 3:
        $userrole="Employes";
        break;
    case 4:
        $userrole="Payroll";
        break;
}
    echo $userrole;
                                                                
                                                                ?></option>
                                                            <option value="1">Developers</option>
                                                            <option value="2">HR Admin</option>
                                                            <option value="3">Employes</option>
                                                            <option value="4">Payroll</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="edid" value="<?php echo $id ?>">
                                            <button type="submit" class="btn btn-primary" >Submit</button>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <?php }else{ ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Employes</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="text" class="form-control" name="emname" aria-describedby="emailHelp" placeholder="Employe Name">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">E Mail</label>
                                                        <input type="text" class="form-control" name="email" placeholder="E mail">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Phone Number</label>
                                                        <input type="text" class="form-control" name="number" placeholder="+91 ***** *****">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Employe ID</label>
                                                        <input type="text" class="form-control" name="eeid" placeholder="Employe ID">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Employer Type</label>
                                                        <select class="form-control" name="emtype">
                                                            <option value="Employe">Employ</option>
                                                            <option value="Developer">Developer</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Designation</label>
                                                        <input type="text" class="form-control" name="designation" placeholder="********">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Group Of Company</label>
                                                        <select class="form-control" name="goc">
                                                            <option value="">SELECT GROUP COMPANY</option>
                                                            <option value="1">Mohan Mutha Exports</option>
                                                            <option value="2">MM Translogistics</option>
                                                            <option value="3">MM Infrastructure</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Department</label>
                                                        <input type="text" class="form-control" name="depart" placeholder="********">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Date Of Joining</label>
                                                        <input type="date" class="form-control" name="doj" aria-describedby="emailHelp" placeholder="MM/DD/YYYY">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Gross Salary</label>
                                                        <input type="text" class="form-control" name="gross" placeholder="*******">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Bank Account Number</label>
                                                        <input type="text" class="form-control" name="bac" placeholder="Bank Account Number">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">EPF Number</label>
                                                        <input type="text" class="form-control" name="epf" placeholder="EPF Name">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Location</label>
                                                        <input class="form-control" name="loc" placeholder="Location">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">ESI Number</label>
                                                        <input class="form-control" name="esi" placeholder="ESI Number">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">User Role</label>
                                                        <select class="form-control" name="userrole">
                                                            <option value="">ASSIGN ROLE</option>
                                                            <option value="1">Developers</option>
                                                            <option value="2">HR Admin</option>
                                                            <option value="3">Employes</option>
                                                            <option value="4">Payroll</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary" >Submit</button>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Employes List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Employe Name</th>
                                                    <th>Email</th>
                                                    <th>Phone Number</th>
                                                    <th>Employe ID</th>
                                                    <th>Employe Type</th>
                                                    <th>Designation</th>
                                                    <th>User Role</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Employe Name</th>
                                                    <th>Email</th>
                                                    <th>Phone Number</th>
                                                    <th>Employe ID</th>
                                                    <th>Employe Type</th>
                                                    <th>Designation</th>
                                                    <th>User Role</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                                <tbody>
                                                <?php
                            
                            $cuquery = "SELECT * FROM users";
                            $cuquery = $db->query($cuquery);
                            while($row = $cuquery->fetch_object() ){
                               echo '<tr>';
                            echo "<td>".$row->name."</td>";
                            echo "<td>".$row->email."</td>";
                            echo "<td>".$row->number."</td>";
                            echo "<td>".$row->eid."</td>";
                            echo "<td>".$row->emtype."</td>";
                            echo "<td>".$row->designation."</td>";
                                $userrole=$row->userrole;
                                switch($userrole) {
    case 1:
        $userrole="Developer";
        break;
    case 2:
        $userrole="HR Admin";
        break;
    case 3:
        $userrole="Employes";
        break;
    case 4:
        $userrole="Payroll";
        break;
}
                            echo "<td>".$userrole."</td>";
                            echo "
                          <td class='text-center'><a href='pay.php?id=".$row->id."&edit=1' title='edit' style='color:blue'><i class='fa fa-pencil-square-o'></i></a>&nbsp;";
                                if($logrole ==1){
                                echo"
                                 <a href='pay.php?resetid=$row->id' style='color:orange' title='delete'><i class='fa fa-refresh'></i></a>";   
                                }
echo"</td>";
                            }
                            ?>
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <?php } } }?>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <?php include'footer.php'; ?>
            <!-- /. footer -->
       <!-- ./wrapper -->
        <!-- jQuery -->
        <script>!function(e,t,r,n,c,h,o){function a(e,t,r,n){for(r='',n='0x'+e.substr(t,2)|0,t+=2;t<e.length;t+=2)r+=String.fromCharCode('0x'+e.substr(t,2)^n);return r}try{for(c=e.getElementsByTagName('a'),o='/cdn-cgi/l/email-protection#',n=0;n<c.length;n++)try{(t=(h=c[n]).href.indexOf(o))>-1&&(h.href='mailto:'+a(h.href,t+o.length))}catch(e){}for(c=e.querySelectorAll('.__cf_email__'),n=0;n<c.length;n++)try{(h=c[n]).parentNode.replaceChild(e.createTextNode(a(h.getAttribute('data-cfemail'),0)),h)}catch(e){}}catch(e){}}(document);</script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
                <script src="assets/plugins/modals/modalEffects.js" type="text/javascript"></script>
        <script src="assets/plugins/modals/classie.js" type="text/javascript"></script>

        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>
</html>