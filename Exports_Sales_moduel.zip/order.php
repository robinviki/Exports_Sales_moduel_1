<?php

include 'functions/config.php';

if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}
if(!empty($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == 5){
        $msg = "<p align='center' style='color:green;'>Created Successfully</p>";
    }
    if($msg == 6){
        $msg = "<p align='center' style='color:green;'>Updated Successfully</p>";
    }
    if($msg == 7){
        $msg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
}
if(!empty($_GET['cmsg'])){
    $cmsg = $_GET['cmsg'];
    if($cmsg == 7){
        $cmsg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
    if($cmsg == 5){
        $cmsg = "<p align='center' style='color:red;'>Created Successfully</p>";
    }
}
if(!empty($_GET['enq'])){
    $enq= $_GET['enq'];
}
if(!empty($_GET['edito'])){
    $edito= $_GET['edito'];
}
if(!empty($_GET['orid'])){
    $orid= $_GET['orid'];
}
if(!empty($_GET['id'])){
    $id = $_GET['id'];
    $randi = rand();

                               

                            $eq = "SELECT * FROM enquiry WHERE id = $id";
                                $eq = $db->query($eq);
                            $eq = $eq->fetch_object();
                                $id = $eq->id;
                                $name = $eq->name;
                                $director = $eq->director;
                                    if(!empty($name)){
                                    $cdet = "SELECT * FROM customers WHERE id = $name";
                                    $cdet = $db->query($cdet);
                                    $cdet = $cdet->fetch_object();
                                    $cuid = $cdet->id;
                                    $cname = $cdet->cname;
                                    $cp = $cdet->cpname;
                                    $email = $cdet->cemail;
                                    $mnumber = $cdet->cmnumber;
                                    $pnumber = $cdet->cpnumber;
                                    $address = $cdet->caddress;
                                }
                                $list = "SELECT * FROM parent WHERE eid = $id";
                                $list = $db->query($list);

                            
}

$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group - Orders</title>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">

        <!-- Start Global Mandatory Style
        =====================================================================-->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css"/>
        <!-- End Global Mandatory Style
        =====================================================================-->
        <!-- Start page Label Plugins 
        =====================================================================-->
        <!-- dataTables css -->
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- End page Label Plugins 
        =====================================================================-->
        <!-- Start Theme Layout Style
        =====================================================================-->
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
        <!-- End Theme Layout Style
        =====================================================================-->
    </head>
    <body>
        <div class="wrapper animsition">
            <!-- main header -->
            <?php include'header.php'; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="order.php"><i class="fa fa-paperclip"></i></a>
                            </div>
                            <div class="header-title">
                                <h1>&nbsp;Orders</h1>
                                <small>You can Generate order Pricing Sheet from enquiries</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Sales Management</a></li>
                                    <li><a href="enquiry.php">Enquiry</a></li>
                                    <li class="active">Orders</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <?php 
                        if(!empty($edito)){
                            ?>
                        <div class="row">
                        <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Edit enquiry Pricing Sheet   --  Enquiry Code: <?php echo $orid; ?></h4>
                                        </div>
                                    </div>
                            <?php 
                            if(!empty($orid)){
                                $selenq = "SELECT * FROM parent WHERE randi= $orid";
                                $seleno = $db->query($selenq);
                                $sele = $seleno->fetch_object();
                                $eid = $sele->eid;
                                $sel = $sele->sel;
                                $sel = $sel - 1;
                                $salec = $sele->salec;
                            
                            ?>
                            
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php">
                                            
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Enquiry ID</label>
                                                        <input type="text" class="form-control" name="enid" placeholder="note" value="<?php echo $eid; ?>" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">No. of Products</label>
                                                        <input type="text" class="form-control" name="nop" placeholder="note" value="<?php echo $sel; ?>"readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sales Co ordinator</label>
                                                        <input type="text" class="form-control" name="sc" placeholder="note" value="<?php echo $salec; ?>" readonly>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Justicification Remarks</label>
                                                        <input type="text" class="form-control" name="jr" placeholder="note">
                                                        <small>Mention any remarks to updated in order pricing sheet</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Revision</label>
                                                        <input type="text" class="form-control" name="rv" placeholder="note">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <?php 
                                            $ordsel = "SELECT * FROM orders WHERE randid= $orid";
                                            $ordsel = $db->query($ordsel);
                                $i =1;
                                            while($ords = $ordsel->fetch_object()){
                                                
                                                $oid = $ords->id;
                                            $slno = $ords->slno;
                                            $pname = $ords->pname;
                                            $des = $ords->des;
                                            $qty = $ords->qty;
                                            $uom = $ords->uom;
                                            $rate = $ords->rate;
                                            $total = $ords->total;
                                            $cost1 = $ords->cost1;
                                            $wepc = $ords->wepc;
                                            $cost2 = $ords->cost2;
                                            $pac = $ords->pac;
                                            $hand = $ords->hand;
                                            $lfrt = $ords->lfrt;
                                            $otrchr = $ords->otrchr;
                                            $conv = $ords->conv;
                                            $usdprice = $ords->usdprice;
                                            $usdt = $ords->usdt;
                                            $sftr = $ords->sftr;
                                            $ins = $ords->ins;
                                            $pftv = $ords->pftv;
                                            $usdoc = $ords->usdoc;
                                            $cif = $ords->cif;
                                            
                                            ?>
                                            <div class="row">
                                                <div class="col-md-1">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sl. No.</label>
                                                        <input type="text" class="form-control" name="sln<?php echo $i;?>" placeholder="note" value="<?php echo $slno; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputPassword1">Products</label>
                                                            <textarea type="text" class="form-control" name="prd<?php echo $i;?>" rows="6" placeholder="note"><?php echo $pname; ?></textarea>

                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="exampleInputPassword1">Product Description</label>
                                                            <textarea type="text" class="form-control" name="prdes<?php echo $i;?>" placeholder="note" rows="3"><?php echo $des; ?></textarea>

                                                        </div>
                                                    </div>
                                                    </div>
                                                <div class="col-md-8">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Qty</label>
                                                        <input type="text" class="form-control" name="qty<?php echo $i;?>" placeholder="note" value="<?php echo $qty; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">UOM</label>
                                                        <input type="text" class="form-control" name="uom<?php echo $i;?>" placeholder="note" value="<?php echo $uom; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Rate / UOM</label>
                                                        <input type="text" class="form-control" name="rpu<?php echo $i;?>" placeholder="note" value="<?php echo $rate; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1" style="color:green">Total Amount</label>
                                                        <input type="text" class="form-control" style="color:green" name="ta<?php echo $i;?>" placeholder="note" value="<?php echo $total; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Cost 1</label>
                                                        <input type="text" class="form-control" name="cst1<?php echo $i;?>" placeholder="" value="<?php echo $cost1; ?>" >
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Weight</label>
                                                        <input type="text" class="form-control" name="wei<?php echo $i;?>" placeholder="" value="<?php echo $wepc; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Cost 2</label>
                                                        <input type="text" class="form-control" name="cst2<?php echo $i;?>" placeholder="" value="<?php echo $cost2; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Packaging</label>
                                                        <input type="text" class="form-control" name="pck<?php echo $i;?>" placeholder="" value="<?php echo $pac; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Handling</label>
                                                        <input type="text" class="form-control" name="hnd<?php echo $i;?>" placeholder="" value="<?php echo $hand; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Local Frt</label>
                                                        <input type="text" class="form-control" name="lfrt<?php echo $i;?>" placeholder="" value="<?php echo $lfrt; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Othr Char</label>
                                                        <input type="text" class="form-control" name="otr<?php echo $i;?>" placeholder="" value="<?php echo $otrchr; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Conv. Fact</label>
                                                        <input type="text" class="form-control" name="cfact<?php echo $i;?>" placeholder="" value="<?php echo $conv; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">USD Price</label>
                                                        <input type="text" class="form-control" name="usdp<?php echo $i;?>" placeholder="" value="<?php echo $usdprice; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">USD Total</label>
                                                        <input type="text" class="form-control" name="usdt<?php echo $i;?>" placeholder="" value="<?php echo $usdt; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sea / Air Frt</label>
                                                        <input type="text" class="form-control" name="sfrt<?php echo $i;?>" placeholder="" value="<?php echo $sftr; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Insurance</label>
                                                        <input type="text" class="form-control" name="ins<?php echo $i;?>" placeholder="" value="<?php echo $ins; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Prt Value</label>
                                                        <input type="text" class="form-control" name="ptv<?php echo $i;?>" placeholder="" value="<?php echo $pftv; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Othr Chrg</label>
                                                        <input type="text" class="form-control" name="oth<?php echo $i;?>" placeholder="" value="<?php echo $usdoc; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1" style="color:green"><strong>CIF</strong></label>
                                                        <input type="text" class="form-control"  style="color:green" name="cif<?php echo $i;?>" placeholder="note" value="<?php echo $cif; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1" style="color:red"><strong>Bulk Delete</strong></label>
                                                        <select class="form-control" name="bulkdelete">
                                                            <option value="0" style="color:green">No</option>
                                                            <option value="1" style="color:red">Yes</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2" align="center">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1" style="color:red"><strong>Delete</strong></label><br>
                                                        <a href="functions/admirebox.php?ordelid=<?php echo $idr?>&randi=<?php echo $orid?>&enid=<?php echo $eid; ?>" style="color:red"><i class="fa fa-trash"></i></a>
                                                        
                                                    </div>
                                                </div>
                                                    </div>
                                                <input type="hidden" name="oid<?php echo $i; ?>" value="<?php echo $oid; ?>">
                                            </div>
                                            <?php $i++;} ?>
                                            <input type="hidden" name="" value="<?php echo $cuid; ?>">
                                                <input type="hidden" name="randi" value="<?php echo $orid;?>">
                                                <input type="hidden" name="" value="<?php echo $id?>">
                                            <button type="submit" name="orup" class="btn btn-primary">Update</button>
                                            <button type="submit" name="orrev" class="btn btn-primary">Reviced</button>
                                        </form>
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                            <?php } ?>
                            
                                </div>
                        </div>
                        <?php
                            
                        }else{
                        ?>
                        
                        <div class="row">
                        <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add Category / Category List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <?php echo (!empty($cmsg) ? $cmsg : "") ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                        <form method="post" action="functions/admirebox.php">
                                            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Category</label>
                                                        <input type="text" class="form-control" name="cat">
                                                        <input type="hidden" class="form-control" name="ord" value="<?php echo $id ?>">
                                                        <small>Create a new Category</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1" style="color:transparent">.</label>
                                                        <button type="submit" class="btn btn-primary form-control">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </form>
                                                </div>
                                            </div>
                                        <div class="table-responsive">
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Category ID</th>
                                                    <th>Category</th>
                                                    <?php
                                                    if($logrole==1){ ?>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                <?php } ?>
                                                    </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Created Date</th>
                                                    <?php
                                                    if($logrole==1){ ?>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                <?php } ?>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                
                                                
                                                <?php
                                                      $categ = "SELECT * FROM categories";
                                        $cate = $db->query($categ);
                            while($cat = $cate->fetch_object() ){
                               echo '<tr>';
                            echo "<td>".$cat->id."</td>";
                            echo "<td>".$cat->cname."</td>";
                                if($logrole==1){
                            echo "
                          <td class='text-center'>
                                                        <a href='functions/admirebox.php?ord=$id&catdelete=$cat->id' style='color:red' title='delete'><i class='fa fa-times'></i></a></td>";   
                                }
                            }
                            ?>
                                
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>New Order Pricing Sheet</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php" enctype="multipart/form-data">
                                            
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Upload</label>
                                                        <input type="file" class="form-control" name="file">
                                                        <small>Upload only csv file</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Justicification Remarks</label>
                                                        <input type="text" class="form-control" name="note" placeholder="note">
                                                        <small>Mention any remarks to updated in order pricing sheet</small>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Revision</label>
                                                        <input type="text" class="form-control" name="revi" placeholder="note">
                                                        <small>Mention any remarks to updated in order pricing sheet</small>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="cid" value="<?php echo $cuid; ?>">
                                                <input type="hidden" name="randi" value="<?php echo $randi?>">
                                                <input type="hidden" name="enid" value="<?php echo $id?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Pricing Sheet List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Created Date</th>
                                                    <th>Last Modified</th>
                                                    <th>total number of product</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Created Date</th>
                                                    <th>Last Modified</th>
                                                    <th>total number of product</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                
                                                
                                                <?php
                                                        
                            while($row = $list->fetch_object() ){
                                $cel=$row->sel;
                                $cel=$cel-1;
                               echo '<tr>';
                            echo "<td>".$row->id."</td>";
                            echo "<td>".$row->created."</td>";
                            echo "<td>".$row->modified."</td>";
                            echo "<td>".$cel."</td>";
                            echo "
                          <td class='text-center' style='font-size:18px'>
                                                        <a href='order.php?edito=1&enid=".$row->eid."&orid=".$row->randi."' title='edit' style='color:blue'><i class='fa fa-pencil-square-o'></i></a>&nbsp;
                                                        <a href='epdf.php?enid=".$row->eid."&orid=".$row->randi."' target='blank' style='color:red' title='Generate Order Pricing Sheet'><i class='fa fa-file-pdf-o'></i></a>&nbsp;
                                                        <a href='quote.php?id=".$row->id."&orid=".$row->randi."' style='color:green' title='Create Quotation'><i class='fa fa-arrow-circle-right'></i></a>&nbsp;";
                                if($logrole == 1){
                                    echo "
                                                        <a href='functions/admirebox.php?ord=$id&prdelete=$row->randi' style='color:red' title='delete'><i class='fa fa-times'></i></a>";   
                                                        }
                                echo "</td>";
                            }
                            ?>
                                
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="card-header-menu">
                                            <i class="fa fa-bars"></i>
                                        </div>
                                        <div class="card-header-headshot"></div>
                                    </div>
                                    <div class="card-content">
                                        <div class="card-content-member">
                                            <h4 class="m-t-0"><?php echo $cname; ?></h4>
                                            <p class="m-0"><i class="fa fa-user"></i><?php echo $cp; ?></p>
                                            <p class="m-0"><i class="fa fa-id-card-o" aria-hidden="true"></i><?php echo $cuid; ?></p>
                                        </div>
                                        <div class="card-content-languages">
                                            <div class="card-content-languages-group">
                                                <div>
                                                    <h4>Email ID:</h4>
                                                </div>
                                                <div>
                                                    <ul>
                                                        <li><a href="mailto:<?php echo $email;?>"><?php echo $email; ?></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="card-content-languages-group">
                                                <div>
                                                    <h4>Phone : <?php echo $pnumber; ?></h4>
                                                </div>
                                            </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="card-content-languages-group">
                                                <div>
                                                    <h4>Mobile : <?php echo $mnumber; ?></h4>
                                                </div>
                                            </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="card-content-summary">
                                            
                                        <div class="card-content-languages-group">
                                                <div>
                                                    <h4>Address :</h4>
                                                </div>
                                            </div>
                                            <p><?php echo $address; ?></p>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <div class="card-footer-stats">
                                            <div>
                                                <?php 
                                                $endetails = "SELECT * FROM enquiry WHERE name=$cuid";
                                                $endet = $db->query($endetails);
                                                $enquiries = $endet->num_rows;
                                                ?>
                                                <p>ENQUIRIES:</p><i class="fa fa-bar-chart"></i> <span><?php echo $enquiries;?></span>
                                            </div>
                                            <div>
                                                <p>QUOTATIONS:</p><span class="stats-small">Comming Soon</span>
                                            </div>
                                            <div>
                                                <p>CONVERSIONS:</p><span class="stats-small">Comming Soon</span>
                                            </div>
                                        </div>
                                        <div class="card-footer-message">
                                            <h4><a href="customers.php?id=<?php echo $cuid; ?>&edit=1" style="color:#fff;"><i class="fa fa-edit"></i> Edit Customer Details</a></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php }?>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <?php include'footer.php'; ?>
            <!-- /. footer -->
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script>!function(e,t,r,n,c,h,o){function a(e,t,r,n){for(r='',n='0x'+e.substr(t,2)|0,t+=2;t<e.length;t+=2)r+=String.fromCharCode('0x'+e.substr(t,2)^n);return r}try{for(c=e.getElementsByTagName('a'),o='/cdn-cgi/l/email-protection#',n=0;n<c.length;n++)try{(t=(h=c[n]).href.indexOf(o))>-1&&(h.href='mailto:'+a(h.href,t+o.length))}catch(e){}for(c=e.querySelectorAll('.__cf_email__'),n=0;n<c.length;n++)try{(h=c[n]).parentNode.replaceChild(e.createTextNode(a(h.getAttribute('data-cfemail'),0)),h)}catch(e){}}catch(e){}}(document);</script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>
</html>