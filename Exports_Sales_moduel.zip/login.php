<?php
include 'functions/config.php';



if(!empty($_SESSION['userid'])){
    
    header("Location: dashboard.php");
    
}

if(!empty($_GET['msg'])){
    
    $msg = $_GET['msg'];
    
    if($msg == 1){
        $msg = "<p align='center' style='color:red;'>Invalid Credentials</p>";
    }
    
    if($msg == 2){
        $msg = "<p align='center' style='color:red;'>Credentials Missmatch</p>";
    }
    
    if($msg == 3){
        $msg = "<p align='center' style='color:red;'>Kindly Provide different Credentials</p>";
    }
    
    if($msg == 4){
        $msg = "<p align='center' style='color:green;'>Credentials Changed Successfully. <br> Login With New Credentials</p>";
    }
    
    
}
if(!empty($_GET['changu'])){
    $changeid = $_GET['changu'];
    
}
if(!empty($_GET['forgot'])){
    $fogid = $_GET['forgot'];
}
if(!empty($_GET['fogrand'])){
    $fogrand = $_GET['fogrand'];
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group Employee Desk</title>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">

        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <!-- Bootstrap rtl -->
        <!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
        <!-- Pe-icon-7-stroke -->
        <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <!-- Content Wrapper -->
        <div class="login-wrapper">
            <div class="container-center">
                <div class="panel panel-bd">
                    <div class="panel-heading" align="center">
                        <img src="assets/logo.png" alt="Mohan Mutha Group">
                        <div class="view-header">
                            <div class="header-icon">
                                <i class="pe-7s-unlock"></i>
                            </div>
                            <div class="header-title">
                                <h3>Login</h3>
                                <p><strong>Enter your credentials to login.</strong></p>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form action="functions/admirebox.php" method="post">
                            <!--Social Buttons--> 
                           <?php
                                if(!empty($fogid)){ ?>
                                    <div class="form-group">
                                <label class="control-label">Employee Id</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input name="forgot" type="text" class="form-control" placeholder="Enter Your Employee Id">
                                </div>
                                <span class="help-block small">Your employee id to app</span>
                            </div>
                            <?php if(!empty($fogrand)){ ?>
                            <p style="color:green" align="center"> Password Reset Request Code is <strong><?php echo $fogrand ?></strong>. Kindly email the request code to <strong>webdeveloper@mmexports.com</strong>. </p>
                            
                            <br>
                            <br>
                            <small> <a href="login.php"><i class="fa fa-arrow-left"></i> bcak to login</a></small>
                               <?php  }}else{
                               if(empty($changeid)) {
                            ?>
                            <div class="form-group">
                                <label class="control-label">Employee Id</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input name="eid" type="text" class="form-control" placeholder="Username">
                                </div>
                                <span class="help-block small">Your employee id to app</span>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                    <input name="pass" type="password" class="form-control" name="password" placeholder="******">
                                </div>
                                
                            </div>
                            <small><strong><a href="login.php?forgot=1">Forgot Password ?</a></strong></small>
                            <?php }if(!empty($changeid)){
                            
                            $changepass = "SELECT * FROM users WHERE id=$changeid";
                            $changepas = $db->query($changepass);
                            $chanpas = $changepas->fetch_object();
                            $chaname = $chanpas->name;
                            $chaname = md5($chaname);
                            $chapass = $chanpas->pass;
                            $chapaypass = $chanpas->paypass;
                                   if($chaname == $chapass){
                            ?>
                            <div class="form-group">
                                <label class="control-label">New Login Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input type="password" class="form-control" name="newpass" placeholder="******">
                                </div>
                                <span class="help-block small">Donot share your password.</span>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Conform Login Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                    <input type="password" class="form-control" name="newcpass" placeholder="******">
                                </div>
                                
                            </div>
                            <?php }
                            if($chapass == $chapaypass){
                            ?>
                            <div class="form-group">
                                <label class="control-label">Generate Payslip Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                    <input type="password" class="form-control" name="paypass" placeholder="******">
                                </div>
                                <span class="help-block small">Donot share your password.</span>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Conform Payslip Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                    <input type="password" class="form-control" name="cpaypass" placeholder="******">
                                    <input type="hidden" class="form-control" name="emid" value="<?php echo $changeid; ?>">
                                </div>
                                
                            </div>
                            
                            <?php }}} ?>
                            <div>
                                <button class="btn btn-primary pull-right">Login</button>
                                <?php echo (!empty($msg) ? $msg : ""); ?>
                            </div>
                        </form>
                    </div>
                </div>
                

            </div>
        </div>
        <!-- /.content-wrapper -->
        <!-- jQuery -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    </body>
</html>