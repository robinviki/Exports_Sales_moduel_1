<?php

session_start();
if(!empty($_GET['ch'])){
    session_destroy();
header ("Location: login.php?ch=1");

}else{
    session_destroy();
header ("Location: index.php");

}


?>