<?php



include 'functions/config.php';

if(!empty($_GET['payid'])){
   
    $randi = $_GET['payid'];
    $select = "SELECT * FROM upay WHERE rand= $randi";
    $selec = $db->query($select);
    $sel = $selec->fetch_object();
    $payid = $sel->payid;
    
        if(!empty($payid)){
            
            $uselect = "SELECT * FROM users WHERE id= $payid";
                                                    $uselec = $db->query($uselect);
                                                    $sele = $uselec->fetch_object();
    $edid=$sele->id;
            
                                                    $emname = $sele->name;
                                                    $email = $sele->email;
                                                    $number = $sele->number;
                                                    $eid = $sele->eid;
                                                    $emtype = $sele->emtype;
                                                    $designation = $sele->designation;
                                                    $goc = $sele->goc;
                                                    $depart = $sele->depart;
                                                    $doj = $sele->doj;
                                                    $loc = $sele->loc;
                                                    $gross = $sele->gross;
                                                    $bac = $sele->bac;
                                                    $uepf = $sele->epf;
                                                    $uesi = $sele->esi;
                                                    $userrole = $sele->userrole;
        }
    
    
    $month = $sel->month;
    $dateObj   = DateTime::createFromFormat('!m', $month);
$month = $dateObj->format('F');
    $year = $sel->year;
    $dim = $sel->dim;
    $lop = $sel->lop;
    $dw = $sel->dw;
    $basicg = $sel->basicg;
    $dag = $sel->dag;
    $hrag = $sel->hrag;
    $conveyg = $sel->conveyg;
    $mediag = $sel->mediag;
    $tgross = $sel->tgross;
    $basice = $sel->basice;
    $dae = $sel->dae;
    $hrae = $sel->hrae;
    $conveye = $sel->conveye;
    $medicale = $sel->medicale;
    $bonuse = $sel->bonuse;
    $otherse = $sel->otherse;
    $egross = $sel->egross;
    $epf = $sel->epf;
    $esi = $sel->esi;
    $staff = $sel->staff;
    $tds = $sel->tds;
    $othersd = $sel->othersd;
    $totald = $sel->totald;
    $netpay = $sel->netpay;
    
    
    
    function no_to_words($no)
{   
 $words = array('0'=> '' ,'1'=> 'one' ,'2'=> 'two' ,'3' => 'three','4' => 'four','5' => 'five','6' => 'six','7' => 'seven','8' => 'eight','9' => 'nine','10' => 'ten','11' => 'eleven','12' => 'twelve','13' => 'thirteen','14' => 'fouteen','15' => 'fifteen','16' => 'sixteen','17' => 'seventeen','18' => 'eighteen','19' => 'nineteen','20' => 'twenty','30' => 'thirty','40' => 'fourty','50' => 'fifty','60' => 'sixty','70' => 'seventy','80' => 'eighty','90' => 'ninty','100' => 'hundred and','1000' => 'thousand','100000' => 'lakh','10000000' => 'crore');
    if($no == 0)
        return ' ';
    else {
	$novalue='';
	$highno=$no;
	$remainno=0;
	$value=100;
	$value1=1000;       
            while($no>=100)    {
                if(($value <= $no) &&($no  < $value1))    {
                $novalue=$words["$value"];
                $highno = (int)($no/$value);
                $remainno = $no % $value;
                break;
                }
                $value= $value1;
                $value1 = $value * 100;
            }       
          if(array_key_exists("$highno",$words))
              return $words["$highno"]." ".$novalue." ".no_to_words($remainno);
          else {
             $unit=$highno%10;
             $ten =(int)($highno/10)*10;            
             return $words["$ten"]." ".$words["$unit"]." ".$novalue." ".no_to_words($remainno);
           }
    }
}
    
    
    $netword = no_to_words($netpay);
    //$netword = strtoupper($netword);
    

    
}


require('fpdf/fpdf.php');

class myPDF extends FPDF {
    function myCell($w,$h,$x,$t){
        $height=$h/2;
        $first=$height+2;
        $second=$height+$height+3;
        $third=$height+$height+$height+4;
        $len=strlen($t);
        if($len>24){
            $txt=str_split($t,24);
            $this->SetX($x);
            $this->Cell($w,$first,$txt[0],'','','');
            $this->SetX($x);
            $this->Cell($w,$second,$txt[1],'','','');
            $this->SetX($x);
            $this->Cell($w,$third,$txt[2],'','','');
            $this->SetX($x);
            $this->Cell($w,$h,'','LTRB',0,'C',0);
        }
        else{
            $this->SetX($x);
            $this->Cell($w,$h,$t,'LTRB',0,'C',0);
        }
    }
}
$pdf = new myPDF('p','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Helvetica','',10);
$pdf->Ln();

$w=35;
$h=20;
$image = "paylogo.png";
$pdf->SetFillColor(221, 217, 196);
//set font arial, bold, 14pt
$pdf->SetFont('Arial','B',10);
//Cell(width, height , text , border , end line , [align] );

switch ($goc) {
    case 1:
        $img = "paylogo1.png";
        break;
    case 2:
        $img = "paylogo2.png";
        break;
    case 3:
        $img = "paylogo3.png";
        break;
}

$pdf->Image("assets/$img",130,10,70);
$pdf->Ln(12);
$pdf->Cell(100, 5, 'Pay Slip',0,1);
$pdf->Cell(100, 5, "$month - $year",0,1);
$pdf->Ln();

//1st line
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(198, 217, 241);
$pdf->Cell(190, 8, " $emname",1,1,'',true);
//1st line

//2nd line
$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Emp.No:',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $eid",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' Bank A/C No',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $bac",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' Days in a Month',1,0,'',true);
$pdf->SetFont('Arial','',8);

$pdf->Cell(16, 8, (($dim > 1) ? " $dim Days" : " $dim Day"),1,1,'',true);

//2nd line

//3nd line
$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Designation',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $designation",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' Location',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $loc",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' Loss of Pay',1,0,'',true);
$pdf->SetFont('Arial','',8);
if(!empty($lop)){
$pdf->Cell(16, 8, (($lop > 1) ? " $lop Days" : " $lop Day"),1,1,'',true);
}else{
    $pdf->Cell(16, 8, 0,1,1,'',true);
}
//3nd line

//4nd line
$pdf->SetFont('Arial','B',9);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Department',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $depart",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' EPF UAN No',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $uepf",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' Days Worked',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(16, 8, (($dw > 1) ? " $dw Days" : " $dw Day"),1,1,'',true);
//4nd line

//5nd line
$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' D.O.J',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $doj",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(32, 8, ' ESI No',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $uesi",1,0,'',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(48, 8, ' ',1,1,'',true);
//5nd line

//6st line
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(198, 217, 241);
$pdf->Cell(34, 8, ' Actuals',1,0,'C',true);
$pdf->Cell(38, 8, ' Fixed (INR)',1,0,'C',true);
$pdf->Cell(32, 8, ' Earned (INR)',1,0,'C',true);
$pdf->Cell(38, 8, ' Deductions',1,0,'C',true);
$pdf->Cell(48, 8, ' Amount(INR)',1,1,'C',true);
//6st line

//5nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Basic',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $basicg",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $basice",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' EPF',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($epf) ? " $epf" : "-"),1,1,(!empty($epf) ? "R" : "C"),true);
//5nd line

//6nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' DA',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $dag",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $dae",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' ESI',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($esi) ? " $esi" : "-") ,1,1,(!empty($esi) ? "R" : "C"),true);
//6nd line

//7nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' HRA',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $hrag",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $hrae",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' Staff Loan',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($staff) ? " $staff" : "-"),1,1,(!empty($staff) ? "R" : "C"),true);
//7nd line

//8nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Conveyance',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $conveyg",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $conveye",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' TDS',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($tds) ? " $tds" : "-"),1,1,(!empty($tds) ? "R" : "C"),true);
//8nd line

//9nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Medical Allowances',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $mediag",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $medicale",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' Others',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($othersd) ? " $othersd" : "-"),1,1,(!empty($othersd) ? "R" : "C"),true);
//9nd line

//10nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Others',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' -',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, (!empty($otherse) ? " $otherse" : "-"),1,0,(!empty($otherse) ? "R" : "C"),true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' ',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, '',1,1,'R',true);
//10nd line

//10nd line
$pdf->SetFont('Arial','',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Bonus',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' -',1,0,'C',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, (!empty($bonuse) ? " $bonuse" : "-"),1,0,(!empty($bonuse) ? "R" : "C"),true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, ' ',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, '',1,1,'R',true);
//10nd line

//11nd line
$pdf->SetFont('Arial','B',8);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(34, 8, ' Total Gross (A)',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(38, 8, " $tgross",1,0,'R',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(32, 8, " $egross",1,0,'R',true);
$pdf->SetFont('Arial','B',8);
$pdf->Cell(38, 8, ' Total Deductions (B)',1,0,'',true);
$pdf->SetFont('Arial','',8);
$pdf->Cell(48, 8, (!empty($totald) ? " $totald" : "-"),1,1,(!empty($totald) ? "R" : "C"),true);
//11nd line
$pdf->Ln(2);

//12nd line
$pdf->Cell(104, 8, '',0,0,'');
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(198, 217, 241);
$pdf->Cell(38, 8, ' Net Pay (INR)',1,0,'',true);
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(238, 236, 225);
$pdf->Cell(48, 8, " $netpay",1,1,'C',true);
//12nd line

$pdf->Ln(2);
//12nd line
$pdf->SetFont('Arial','I',10);
$pdf->SetFillColor(198, 217, 241);
$pdf->Cell(190, 8, "Rupees in Words : $netword",0,0);
//12nd line
$pdf->Ln(10);
//12nd line
$pdf->SetFont('Arial','I',9);
$pdf->Cell(100, 8, '* System generated seal and signature not required',0,0,'');
//12nd line
$pdf->Ln();
$pdf->Output();
?>