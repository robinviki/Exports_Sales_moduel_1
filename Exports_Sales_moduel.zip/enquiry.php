<?php

include 'functions/config.php';

if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}
if(!empty($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == 5){
        $msg = "<p align='center' style='color:green;'>Created Successfully</p>";
    }
    if($msg == 6){
        $msg = "<p align='center' style='color:green;'>Updated Successfully</p>";
    }
    if($msg == 7){
        $msg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
}
if(!empty($_GET['enq'])){
    $enq= $_GET['enq'];
}
if(!empty($_GET['id'])){
    $id = $_GET['id'];
}

$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group - Enquiry</title>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">

        <!-- Start Global Mandatory Style
        =====================================================================-->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css"/>
        <!-- End Global Mandatory Style
        =====================================================================-->
        <!-- Start page Label Plugins 
        =====================================================================-->
        <!-- dataTables css -->
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- End page Label Plugins 
        =====================================================================-->
        <!-- Start Theme Layout Style
        =====================================================================-->
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
        <!-- End Theme Layout Style
        =====================================================================-->
    </head>
    <body>
        <div class="wrapper animsition">
            <!-- main header -->
            <?php include'header.php'; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="enquiry.php"><i class="fa fa-eur"></i></a>
                            </div>
                            <div class="header-title">
                                <h1>&nbsp;Enquiry</h1>
                                <small>You can add new enquiry or search existing enquiry from the list </small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Sales Management</a></li>
                                    <li class="active">Enquiry</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        
                        <div class="row">
                            <?php if(!empty($enq)){ 
                            if(!empty($id)){
                            ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>New Enquiry</h4>
                                        </div>
                                    </div>
                                    <?php 
                                if(!empty($id)){
                                    $enquiry = "SELECT * FROM enquiry WHERE id=$id";
                                    $enquire = $db->query($enquiry);
                                    $enqi = $enquire->fetch_object();
                                    $cname = $enqi->name;
                                if(!empty($cname)){
                                    $custom = "SELECT * FROM customers WHERE id=$cname";
                                    $custo = $db->query($custom);
                                    $cust = $custo->fetch_object();
                                    $cuid = $cust->id;
                                    $cuname = $cust->cname;
                                }
                                    $doe = $enqi->doe;
                                    $moe = $enqi->moe;
                                    $pn = $enqi->pn;
                                    $pd = $enqi->pd;
                                    $pq = $enqi->pq;
                                    $qr = $enqi->qr;
                                    $ep = $enqi->ep;
                                    $ds = $enqi->ds;
                                    $pr = $enqi->pr;
                                    $lr = $enqi->lr;
                                    $lb = $enqi->lb;
                                    $otr = $enqi->otr;
                                    $ad = $enqi->ad;
                                    $cfeasi = $enqi->cfeas;
                                    switch ($cfeasi) {
                                    case 1:
                                        $cfeas = "Yes";
                                        break;
                                    case 0:
                                        $cfeas = "No";
                                        break;
                                            
                                }
                                    $pfeasi = $enqi->pfeas;
                                    switch ($pfeasi) {
                                    case 1:
                                        $pfeas = "Yes";
                                        break;
                                    case 0:
                                        $pfeas = "No";
                                        break;
                                            
                                }
                                    $lfeasi = $enqi->lfeas;
                                    switch ($lfeasi) {
                                    case 1:
                                        $lfeas = "Yes";
                                        break;
                                    case 0:
                                        $lfeas = "No";
                                        break;
                                            
                                }
                                    $sc = $enqi->sc;
                                    $director = $enqi->director;
                                    switch ($director) {
                                    case 1:
                                        $dir = "RAMESH KUMAR MUTHA";
                                        break;
                                    case 2:
                                        $dir = "TEJRAJ JAIN";
                                        break;
                                    case 3:
                                        $dir = "VIKAS JAIN";
                                        break;
                                    case 4:
                                        $dir = "KAMALESH JAIN";
                                        break;
                                            
                                }
                                }
                                    ?>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Customer Name</label>
                                                        <select class="form-control" name="ename">
                                                        <option value="<?php echo $cuid; ?>"><?php echo $cuname; ?></option>
                                                        <?php
                                                        $cuquery = "SELECT * FROM customers";
                            $cuquery = $db->query($cuquery);
                            while($crow = $cuquery->fetch_object() ){
                                
                                echo  "<option value='".$crow->id."'>".$crow->cname."-".$crow->cpname."</option>";
                                
                            }
                                                        ?>
                                                    </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Date of Enquiry</label>
                                                        <input type="date" class="form-control" name="edoe" value="<?php echo $doe; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Mode Of Enquiry</label>
                                                        <input type="text" class="form-control" name="emoe" value="<?php echo $moe; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Common Product Name</label>
                                                        <input type="text" class="form-control" name="epn" value="<?php echo $pn; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Common Product Description</label>
                                                        <textarea class="form-control" name="epd" rows="6"><?php echo $pd; ?></textarea>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quantity</label>
                                                        <input type="text" class="form-control" name="epq" value="<?php echo $pq; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Expected Price $</label>
                                                        <input type="number" class="form-control" name="eep" value="<?php echo $ep; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quality Requirements</label>
                                                        <input type="text" class="form-control" name="eqr" value="<?php echo $qr; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Packaging Requirements</label>
                                                        <input type="text" class="form-control" name="epr" value="<?php echo $pr; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Delivery Schedule</label>
                                                        <input type="text" class="form-control" name="eds" value="<?php echo $ds; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Amendment Details</label>
                                                        <input type="text" class="form-control" name="ead" value="<?php echo $ad; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Legal Requirements</label>
                                                        <input type="text" class="form-control" name="elr" aria-describedby="emailHelp" value="<?php echo $lr; ?>">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Labelling Requirements</label>
                                                        <input type="text" class="form-control" name="elb" value="<?php echo $lb; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Other Requirements</label>
                                                        <input type="text" class="form-control" name="eotr" value="<?php echo $otr; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Customer Feasibility</label>
                                                        <select class="form-control" name="ecfeas">
                                                    <option value="<?php echo $cfeasi; ?>"><?php echo $cfeas; ?></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Product Feasibility</label>
                                                        <select class="form-control" name="epfeas">
                                                    <option value="<?php echo $pfeasi; ?>"><?php echo $pfeas; ?></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Lead Feasibility</label>
                                                        <select class="form-control" name="elfeas">
                                                    <option value="<?php echo $lfeasi; ?>"><?php echo $lfeas; ?></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sales Co-ordinator</label>
                                                        <input type="text" class="form-control" name="esc" Value="<?php echo $sc; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Director / BDM</label>
                                                        <select class="form-control" name="edirector">
                                                    <option value="<?php echo $director; ?>"><?php echo $dir; ?></option>
                                                        <option value="1">RAMESH KUMAR MUTHA</option>
                                                        <option value="2">TEJRAJ JAIN</option>
                                                        <option value="3">VIKAS JAIN</option>
                                                        <option value="4">KAMLESH JAIN</option>
                                                    </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <?php }else{?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>New Enquiry</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Customer Name</label>
                                                        <select class="form-control" name="name" required>
                                                        <option value="">Select the Customer</option>
                                                        <?php
                                                        $cuquery = "SELECT * FROM customers";
                            $cuquery = $db->query($cuquery);
                            while($crow = $cuquery->fetch_object() ){
                                
                                echo  "<option value='".$crow->id."'>".$crow->cname."-".$crow->cpname."</option>";
                                
                            }
                                                        ?>
                                                    </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Date of Enquiry</label>
                                                        <input type="date" class="form-control" name="doe" placeholder="DD/MM/YYYY" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Mode Of Enquiry</label>
                                                        <input type="text" class="form-control" name="moe" placeholder="Eg: Email / Phone" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Common Product Name</label>
                                                        <input type="text" class="form-control" name="pn" placeholder="Eg: Cement" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Common Product Description</label>
                                                        <textarea class="form-control" name="pd" rows="6" required></textarea>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quantity</label>
                                                        <input type="text" class="form-control" name="pq" placeholder="Eg: 2 Mton" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Expected Price $</label>
                                                        <input type="number" class="form-control" name="ep" placeholder="Eg: 50">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quality Requirements</label>
                                                        <input type="text" class="form-control" name="qr" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Packaging Requirements</label>
                                                        <input type="text" class="form-control" name="pr" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Delivery Schedule</label>
                                                        <input type="text" class="form-control" name="ds" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Amendment Details</label>
                                                        <input type="text" class="form-control" name="ad" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Legal Requirements</label>
                                                        <input type="text" class="form-control" name="lr" value="N/A" aria-describedby="emailHelp" placeholder="Eg: N/A">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Labelling Requirements</label>
                                                        <input type="text" class="form-control" name="lb" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Other Requirements</label>
                                                        <input type="text" class="form-control" name="otr" value="N/A" placeholder="Eg: N/A">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Customer Feasibility</label>
                                                        <select class="form-control" name="cfeas" required>
                                                    <option></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Product Feasibility</label>
                                                        <select class="form-control" name="pfeas" required>
                                                    <option></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Lead Feasibility</label>
                                                        <select class="form-control" name="lfeas" required>
                                                    <option></option>
                                                        <option value="1">Yes</option>
                                                        <option value="0">no</option>
                                                    </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Sales Co-ordinator</label>
                                                        <input type="text" class="form-control" name="sc" Value="<?php echo $user; ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Director / BDM</label>
                                                        <select class="form-control" name="director" required>
                                                    <option value="">----SELECT A PERSON----</option>
                                                        <option value="1">RAMESH KUMAR MUTHA</option>
                                                        <option value="2">TEJRAJ JAIN</option>
                                                        <option value="3">VIKAS JAIN</option>
                                                        <option value="4">KAMLESH JAIN</option>
                                                    </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                            <?php }?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Add New Customer</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Name</label>
                                                        <input type="text" class="form-control" name="ecname" aria-describedby="emailHelp" placeholder="Name Of the Company">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Conatct Person</label>
                                                        <input type="text" class="form-control" name="ecpname" placeholder="Contact Person">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Designation</label>
                                                        <input type="text" class="form-control" name="ecdes " placeholder="Designation">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Email</label>
                                                        <input type="email" class="form-control" name="ecemail" placeholder="Email">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Mobile Number</label>
                                                        <input type="number" class="form-control" name="ecmnumber" aria-describedby="emailHelp" placeholder="+1********">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Phone Number</label>
                                                        <input type="number" class="form-control" name="ecpnumber" placeholder="+1********">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Discharge Port</label>
                                                        <input type="text" class="form-control" name="ecdport" placeholder="Eg: Tuticorin">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Final Destination</label>
                                                        <input type="text" class="form-control" name="ecfinald" placeholder="Eg: Male">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Website</label>
                                                        <input type="text" class="form-control" name="ecurl" aria-describedby="emailHelp" placeholder="http://abc.com">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Payment Method</label>
                                                        <input type="text" class="form-control" name="ecpaym" placeholder="Eg: Cheque / TT / DD">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Group Companies</label>
                                                        <input type="text" class="form-control" name="ecgroup" placeholder="Group Companies">
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Products</label>
                                                        <input type="text" class="form-control" name="ecproduct" placeholder="Product Name">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Bank Detail</label>
                                                        <textarea class="form-control" name="ecbank" rows="3"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="exampleTextarea">Address</label>
                                                        <textarea class="form-control" name="ecaddress" rows="3"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
<?php }else{ ?>
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Customers List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Customer Name</th>
                                                    <th>Date of Enquiry</th>
                                                    <th>Product Name</th>
                                                    <th>product Description</th>
                                                    <th>product quantity</th>
                                                    <th>Sales Co.</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Customer Name</th>
                                                    <th>Date of Enquiry</th>
                                                    <th>Product Name</th>
                                                    <th>product Description</th>
                                                    <th>product quantity</th>
                                                    <th>Sales Co.</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                
                                                
                                                
                                                <?php
                            
                                 $squery = "SELECT * FROM enquiry";
                                    $squery = $db->query($squery);
                            while($row = $squery->fetch_object() ){
                               echo '<tr>';
                            echo "<td>".$row->id."</td>";
                                $name = $row->name;
                                if(!empty($name));{
                                    $name = "SELECT * FROM customers WHERE id = $name";
                                    $name = $db->query($name);
                                    $name = $name->fetch_object();
                                    $name = $name->cname;
                                }
                            echo "<td>".$name."</td>";
                            echo "<td>".$row->doe."</td>";
                            echo "<td>".$row->pn."</td>";
                            echo "<td>".$row->pd."</td>";
                            echo "<td>".$row->pq."</td>";
                            echo "<td>".$row->sc."</td>";
                            echo "
                          <td class='text-center' style='font-size:18px'><a href='enquiry.php?enq=1&id=".$row->id."&edit=1' title='edit' style='color:blue'><i class='fa fa-pencil-square-o'></i></a>&nbsp;
                                                        <a href='epdf.php?eid=".$row->id."' target='blank' style='color:red' title='Generate Enquiry Feasibility Sheet'><i class='fa fa-file-pdf-o'></i></a>&nbsp;
                                                        <a href='order.php?id=".$row->id."' style='color:green' title='Order Pricing Sheet'><i class='fa fa-arrow-circle-right'></i></a>&nbsp;";
                                if($logrole == 1){
                                    echo "<a href='functions/admirebox.php?edelete=$row->id' style='color:red' title='delete'><i class='fa fa-times'></i></a>";
                                    }
                                    echo "</td>";  
                                
                            }
                            ?>
                                
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div> <!-- /.main content -->
                </div> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <?php include'footer.php'; ?>
            <!-- /. footer -->
        </div> <!-- ./wrapper -->
        <!-- jQuery -->
        <script>!function(e,t,r,n,c,h,o){function a(e,t,r,n){for(r='',n='0x'+e.substr(t,2)|0,t+=2;t<e.length;t+=2)r+=String.fromCharCode('0x'+e.substr(t,2)^n);return r}try{for(c=e.getElementsByTagName('a'),o='/cdn-cgi/l/email-protection#',n=0;n<c.length;n++)try{(t=(h=c[n]).href.indexOf(o))>-1&&(h.href='mailto:'+a(h.href,t+o.length))}catch(e){}for(c=e.querySelectorAll('.__cf_email__'),n=0;n<c.length;n++)try{(h=c[n]).parentNode.replaceChild(e.createTextNode(a(h.getAttribute('data-cfemail'),0)),h)}catch(e){}}catch(e){}}(document);</script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    "order": [[ 0, "desc" ]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>
</html>