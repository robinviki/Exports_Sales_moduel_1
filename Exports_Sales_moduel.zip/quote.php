<?php

include 'functions/config.php';

if(empty($_SESSION['userid'])){
    
    header("Location: index.php");
    
}
if(!empty($_GET['msg'])){
    $msg = $_GET['msg'];
    if($msg == 5){
        $msg = "<p align='center' style='color:green;'>Created Successfully</p>";
    }
    if($msg == 6){
        $msg = "<p align='center' style='color:green;'>Updated Successfully</p>";
    }
    if($msg == 7){
        $msg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
}
if(!empty($_GET['cmsg'])){
    $cmsg = $_GET['cmsg'];
    if($cmsg == 7){
        $cmsg = "<p align='center' style='color:red;'>Deleted Successfully</p>";
    }
    if($cmsg == 5){
        $cmsg = "<p align='center' style='color:red;'>Created Successfully</p>";
    }
}
if(!empty($_GET['enq'])){
    $enq= $_GET['enq'];
}
if(!empty($_GET['qid'])){
    $qid= $_GET['qid'];
}
if(!empty($_GET['id'])){
    $id = $_GET['id'];
    $orid = $_GET['orid'];

                               

                         $eq = "SELECT * FROM parent WHERE id = $id";
                                $eq = $db->query($eq);
                            $eq = $eq->fetch_object();
                                $eid = $eq->eid;
                                
                            
}

$logid=$_SESSION['userid'];


$login = "SELECT * FROM users WHERE id = '$logid'";

    $login = $db->query($login);
    

        $ulogin=$login->fetch_object();
$loguser = $ulogin->name;
       $logrole = $ulogin->userrole;
$user = $loguser;

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Mohan Mutha Group - Orders</title>
        <script src="assets/ckeditor/ckeditor.js"></script>

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
        <link rel="apple-touch-icon" type="image/x-icon" href="assets/dist/img/ico/apple-touch-icon-57-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="assets/dist/img/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="assets/dist/img/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="assets/dist/img/ico/apple-touch-icon-144-precomposed.png">
        <script src="ckeditor.js"></script>
        <!-- Start Global Mandatory Style
        =====================================================================-->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css"/>
        <!-- End Global Mandatory Style
        =====================================================================-->
        <!-- Start page Label Plugins 
        =====================================================================-->
        <!-- dataTables css -->
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
        <!-- End page Label Plugins 
        =====================================================================-->
        <!-- Start Theme Layout Style
        =====================================================================-->
        <!-- Theme style -->
        <link href="assets/dist/css/component_ui.min.css" rel="stylesheet" type="text/css"/>
        <!-- Theme style rtl -->
        <!--<link href="assets/dist/css/component_ui_rtl.css" rel="stylesheet" type="text/css"/>-->
        <!-- Custom css -->
        <link href="assets/dist/css/custom.css" rel="stylesheet" type="text/css"/>
        <!-- End Theme Layout Style
        =====================================================================--> 
        <!-- CK Editor
        =====================================================================-->
        
    </head>
    <body>
        <div class="wrapper animsition">
            <!-- main header -->
            <?php include'header.php'; ?> <!-- /. main header -->
            <!-- /.content-wrapper -->
            <?php
            if(!empty($qid)){?>
               <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="order.php"><i class="fa fa-quote-left"></i></a>
                            </div>
                            <div class="header-title">
                                <h1>&nbsp;Quotations</h1>
                                <small>You can Generate Quotations For enquiries</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Sales Management</a></li>
                                    <li><a href="enquiry.php">Enquiry</a></li>
                                    <li><a href="order.php?id=<?php echo $eid;?>">Orders</a></li>
                                    <li class="active">Quotations</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-md-12">
                            <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Quotation Content</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php" enctype="multipart/form-data">
                                            <?php 
                                                if(!empty($qid)){
                                                    $select = "SELECT * FROM quotation WHERE id=$qid";
                                                    $selec = $db->query($select);
                                                    $sele = $selec->fetch_object();
                                                    $quote = $sele->quote;
                                                    $sub = $sele->sub;
                                                }               
                             
                                            ?>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Subject</label><br>
                                                        <small>Enter the subject for the quotation</small>
                                                        <input type="text" class="form-control" name="esub" value="<?php echo $sub; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quotation Body Content</label><br>
                                                        <small>Mention any remarks to be mentioned in Quotation</small>
                                                        <textarea class="form-control ckeditor" name="equote"><?php echo $quote; ?></textarea>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="ordid" value="<?php echo $id; ?>">
                                                <input type="hidden" name="radid" value="<?php echo $orid; ?>">
                                                <input type="hidden" name="qid" value="<?php echo $qid; ?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div> <!-- /.main content -->
                </div> 
           
            <?php }else{ ?>
            <div class="content-wrapper">
                <div class="container">
                    <!-- main content -->
                    <div class="content">
                        <!-- Content Header (Page header) -->
                        <div class="content-header">
                            <div class="header-icon">
                                <a href="order.php"><i class="fa fa-quote-left"></i></a>
                            </div>
                            <div class="header-title">
                                <h1>&nbsp;Quotations</h1>
                                <small>You can Generate Quotations For enquiries</small>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                                    <li><a href="#">Sales Management</a></li>
                                    <li><a href="enquiry.php">Enquiry</a></li>
                                    <li><a href="order.php?id=<?php echo $eid;?>">Orders</a></li>
                                    <li class="active">Quotations</li>
                                </ol>
                            </div>
                        </div> <!-- /. Content Header (Page header) -->
                        <div class="row">
                            <div class="col-md-12">
                            <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Quotation Content</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form method="post" action="functions/admirebox.php" enctype="multipart/form-data">
                                            
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Subject</label><br>
                                                        <small>Enter the subject for the quotation</small>
                                                        <input type="text" class="form-control" name="sub">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Quotation Body Content</label><br>
                                                        <small>Mention any remarks to be mentioned in Quotation</small>
                                                        <textarea class="form-control ckeditor" name="quote"></textarea>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="ordid" value="<?php echo $id; ?>">
                                                <input type="hidden" name="radid" value="<?php echo $orid; ?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                        
                                        <?php echo (!empty($msg) ? $msg : "") ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                                <div class="col-md-12">
                                    
                                
                                    
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Quotation Content</h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        
                                        <div class="table-responsive">
                                            <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Quote Content</th>
                                                    <th>randid</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Reference No</th>
                                                    <th>Quote Content</th>
                                                    <th>randid</th>
                                                    <th class="disabled-sorting text-right">Actions</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                
                                                
                                                
                                                <?php
                            
                                 $squery = "SELECT * FROM quotation WHERE ordid=$id";
                                    $squery = $db->query($squery);
                            while($row = $squery->fetch_object() ){
                               echo '<tr>';
                            echo "<td>".$row->ordid."</td>";
                            echo "<td>".$row->quote."</td>";
                            echo "<td>".$row->radid."</td>";
                            echo "
                          <td class='text-center'><a href='quote.php?id=$id&qid=".$row->id."&orid=$orid' title='edit' style='color:blue'><i class='fa fa-pencil-square-o'></i></a>&nbsp;
                                                        <a href='qpdf.php?id=".$row->id."' target='blank' style='color:green' title='Generate Quotation'><i class='fa fa-file-pdf-o'></i></a>&nbsp;
                                                        <a href='crf.php?conrand=".$row->radid."' style='color:purple' title='Contract Review Form'><i class='fa fa-check'></i></a></td>&nbsp;";
                                if($logrole == 1){
                                                        echo"<td>
                                                        <a href='functions/admirebox.php?qdelete=$row->id' style='color:red' title='delete'><i class='fa fa-times'></i></a></td>"; }  
                            }
                            ?>
                                
                                               
                                                
                                            </tbody>
                                            </table>
                                        </div>
                                       
                                    </div>
                                </div>
                                </div>
                        
                        
                        <div class="row">
                            <div class="col-md-12">
                        <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="panel-title">
                                            <h4>Product List </h4>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <?php echo (!empty($cmsg) ? $cmsg : "") ?>
                                        <form action="functions/admirebox.php" method="post">
                                        <div class="table-responsive">
                                            <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Slno</th>
                                                    <th>Product name</th>
                                                    <th>Description</th>
                                                    <th>Category</th>
                                                    <th>Quantity</th>
                                                    <th>UOM</th>
                                                    <th>Rate</th>
                                                    <th>Total</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Slno</th>
                                                    <th>Product name</th>
                                                    <th>Description</th>
                                                    <th>Category</th>
                                                    <th>Quantity</th>
                                                    <th>UOM</th>
                                                    <th>Rate</th>
                                                    <th>Total</th>
                                                    
                                                </tr>
                                            </tfoot>
                                                
                                            <tbody>
                                                
                                                <?php
                                $order = "SELECT * FROM orders WHERE randid=$orid";
                                        $ord = $db->query($order);
                        $i = 1;
                                        while($row = $ord->fetch_object() ){
                                           
                               echo '<tr>';
                            echo "<td> <input type='checkbox' name='conprod$i' value='$row->id'>".$row->slno."</td>";
                            echo "<td>".$row->pname."</td>";
                            echo "<td>".$row->des."</td>";
                                            $cate=$row->catid;
                                            
                                            if(!empty($cate)){
                                               $cate = "SELECT * FROM categories WHERE id=$cate";
                                                $cat = $db->query($cate);
                                                $ca = $cat->fetch_assoc();
                                               $caty = $ca['cname'];
                                            }
                            echo "<td>".$caty."</td>";
                            echo "<td>".$row->qty."</td>";
                            echo "<td>".$row->uom."</td>";
                            echo "<td>".$row->rate."</td>";
                            echo "<td>".$row->total."</td>";
                                            
                              
                                                        
                            }
                            ?>
                                              
                                
                                               
                                                
                                            </tbody>
                                                   
                                            </table>
                                                
                                        </div>
                                            <input type="hidden" name="conran" value="<?php echo $orid;?>">
                                             <input type="submit" class="btn btn-primary" name="concheck" value="Generate">
                                                    </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        </div>
                    </div> <!-- /.main content -->
                </div><?php } ?> <!-- /.container -->
            </div> <!-- /.content-wrapper -->
            <!-- start footer -->
            <?php include'footer.php'; ?>
            <!-- /. footer -->
        <!-- ./wrapper -->
        <!-- jQuery -->
        <script>!function(e,t,r,n,c,h,o){function a(e,t,r,n){for(r='',n='0x'+e.substr(t,2)|0,t+=2;t<e.length;t+=2)r+=String.fromCharCode('0x'+e.substr(t,2)^n);return r}try{for(c=e.getElementsByTagName('a'),o='/cdn-cgi/l/email-protection#',n=0;n<c.length;n++)try{(t=(h=c[n]).href.indexOf(o))>-1&&(h.href='mailto:'+a(h.href,t+o.length))}catch(e){}for(c=e.querySelectorAll('.__cf_email__'),n=0;n<c.length;n++)try{(h=c[n]).parentNode.replaceChild(e.createTextNode(a(h.getAttribute('data-cfemail'),0)),h)}catch(e){}}catch(e){}}(document);</script><script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
        <!-- jquery-ui -->
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js" type="text/javascript"></script>
        <!-- Bootstrap js -->
        <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- lobipanel js -->
        <script src="assets/plugins/lobipanel/lobipanel.min.js" type="text/javascript"></script>
        <!-- animsition js -->
        <script src="assets/plugins/animsition/js/animsition.min.js" type="text/javascript"></script>
        <!-- bootsnav js -->
        <script src="assets/plugins/bootsnav/js/bootsnav.js" type="text/javascript"></script>
        <!-- SlimScroll js -->
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <!-- FastClick js-->
        <script src="assets/plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
        <!-- End Core Plugins
        =====================================================================-->
        <!-- Start Page Lavel Plugins
        =====================================================================-->
        <!-- dataTables js -->
        <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>
        <!-- Start Theme label Script
        =====================================================================-->
        <!-- Dashboard js -->
        <script src="assets/dist/js/dashboard.js" type="text/javascript"></script>
        <!-- End Theme label Script
        =====================================================================-->
        <script>
            $(document).ready(function () {

                "use strict"; // Start of use strict

                $('#dataTableExample1').DataTable({
                    "dom": "<'row'<'col-sm-6'l><'col-sm-6'f>>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
                    "lengthMenu": [[6, 25, 50, -1], [6, 25, 50, "All"]],
                    "iDisplayLength": 6
                });

                $("#dataTableExample2").DataTable({
                    dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    buttons: [
                        {extend: 'copy', className: 'btn-sm'},
                        {extend: 'csv', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'excel', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                        {extend: 'print', className: 'btn-sm'}
                    ]
                });

            });
        </script>
    </body>
</html>