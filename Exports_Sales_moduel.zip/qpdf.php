<?php
include 'functions/config.php';
if($_GET['id']){
    $id = $_GET['id'];
     $eq = "SELECT * FROM quotation WHERE id = $id";
    $eq = $db->query($eq);
    $eq = $eq->fetch_object();
    $qid = $eq->id;
    $pid = $eq->ordid;
   if(!empty($pid)){
        $pq = "SELECT * FROM parent WHERE id = $pid";
    $pq = $db->query($pq);
    $pq = $pq->fetch_object();
       $enid = $pq->eid;
       $eid=sprintf("%04d", $enid);
    }
    $quote = $eq->quote;
    $radid = $eq->radid;
    $sub = $eq->sub;
    $qcre = $eq->created;
    $qcre = strtotime($qcre);
    $qcre = date("d/m/20y",$qcre);
    $reve  = "SELECT * FROM orders WHERE randid = $radid";
        $reve = $db->query($reve);
        $rev = $reve->fetch_object();
        $revi = $rev->revi;
    
    if(!empty($enid)){
        $en = "SELECT * FROM enquiry WHERE id = $enid";
    $en = $db->query($en);
    $en = $en->fetch_object();
    $cid = $en->name;
        if(!empty($cid)){
            $cu = "SELECT * FROM customers WHERE id = $cid";
    $cu = $db->query($cu);
    $cu = $cu->fetch_object();
            $cname = $cu->cname;
            $caddress = $cu->caddress;
            $cpname = $cu->cpname;
        }
        $sc = $en->sc;
        $bdm = $en->bdm;
        $director = $en->director;
        switch($director){
            case 1:
                $director = "RAMESH KUMAR MUTHA";
                break;
            case 2:
                $director = "TEJRAJ JAIN";
                break;
            case 3:
                $director = "VIKAS JAIN";
                break;
            case 4:
                $director = "KAMLESH JAIN";
                break;
        }
    }
    
    
}

$year =  18;
//$year = substr( $year, -2);
$nyear = $year+1;


require('tcpdf/tcpdf.php');
class MYPDF extends TCPDF {

    
function Header(){
    
        $this->Image('letter.png',0,0,210);
    // Get the current page break margin
        $bMargin = $this->getBreakMargin();

        // Get current auto-page-break mode
        $auto_page_break = $this->AutoPageBreak;

        // Disable auto-page-break
        $this->SetAutoPageBreak(false, 0);

        // Define the path to the image that you want to use as watermark.
        $img_file = 'water.png';

        // Render the image
        $this->Image($img_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);

        // Restore the auto-page-break status
        $this->SetAutoPageBreak($auto_page_break, $bMargin);

        // Set the starting point for the page content
        $this->setPageMark();
    }
     function Footer(){
         $this->SetY(-15);
        $this->Cell(0,10,'SALES/FMT/005',0,0,'L');
        $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
    }
}
	$pdf=new MYPDF('p', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetMargins('10', '50', '10');
	$pdf->AddPage();
    


         
	$pdf->SetFont('Times','B',11);
$pdf->Cell(180,10,"Ref No: MMEPL /$year-$nyear/".(empty($revi) ? $enid : "$enid/R$revi"),0,0,'L');
$pdf->Cell(10,10,"$qcre",0,1,'R');
$pdf->Ln(5);

$pdf->Cell(180,5,"To",0,1,'L');
$pdf->Cell(180,5,"$cname",0,1,'L');
$pdf->MultiCell(100,5,"$caddress",0,'L');
$pdf->Ln(2);

$pdf->SetFont('Times','B',11);
$pdf->Cell(180,10,"Kind Attn : $cpname",0,1,'L');

$pdf->SetFont('Times','BU',11);
$pdf->MultiCell(190,10,"Sub: Quotation for $sub",0,'C');

$pdf->SetFont('Times','',11);
$pdf->Cell(190,10,"With reference to your enquiry, we are glad to quote our best price for the following:",0,1,'L');


$pdf->SetFont('Times','B',11);
$pdf->SetFillColor(221, 217, 196);
$pdf->Cell(10,10,'No',1,0,'C', true);
$pdf->Cell(90,10,'Description',1,0,'C', true);
$pdf->Cell(17,10,'Qty',1,0,'C', true);
$pdf->Cell(12,10,'UOM',1,0,'C', true);
$pdf->Cell(27,10,'Rate/Unit',1,0,'C', true);
$pdf->Cell(30,10,'Amount in USD',1,1,'C', true);
  






        $cuquery = "SELECT * FROM orders WHERE randid = $radid";
    $cuquery = $db->query($cuquery);
$grand_total = 0;
while($c = $cuquery->fetch_object()){   
    

    $cncount = $c->pname;
    $cnc1 = strlen($cncount);
    $cndes = $c->des;
    $cnc2 = strlen($cndes);
    $cnc = $cnc1 + $cnc2;
$h = 10;
    if($cnc > 23){
        $h = 13;
    }
    if($cnc > 25){
        $h = 16;
    }
    if($cnc > 34){
        $h = 15;
    }
    if($cnc > 55){
        $h = 20;
    }
    if($cnc > 74){
        $h = 18;
    }
    if($cnc > 79){
        $h = 24;
    }
    if($cnc > 117){
        $h = 45;
    }
    if($cnc > 140){
        $h = 32;
    }
    if($cnc > 143){
        $h = 28.7;
    }
    if($cnc > 185){
        $h = 30;
    }
    if($cnc > 200){
        $h = 40;
    }
    if($cnc > 230){
        $h = 36;
    }
    if($cnc > 240){
        $h = 50;
    }
    if($cnc > 375){
        $h = 42;
    }
    if($cnc > 460){
        $h = 50;
    }
    if($cnc > 500){
        $h = 63;
    }
    if($cnc > 800){
        $h = 130;
    }
    if(empty($c->rate)){
        $rate = 0;
    }else{
        $rate = $c->rate;
        //$rate = number_format($c->rate,2);
    }
    if(empty($c->total)){
        $total = 0;
    }else{
        $total = number_format($c->total,2);
    }
    $ctotal = $c->total;
    if(!empty($ctotal)){
        $ctotal = $ctotal;
    }else{
        $ctotal = 0;
    }
$grand_total += $ctotal;
$pdf->SetFont('Times','',11);
//$pdf->Cell(10,15,"$c->slno",1,0,'C');
    $pdf->MultiCell(10, $h, "$c->slno", 1, 'C', 0, '', '');
    //$pdf->MultiCell(10, $h, "$cnc", 1, 'C', 0, '', '');
    $pdf->MultiCell(90, $h, "$c->pname \n $c->des", 1, 'L', 0, '', '');
    $pdf->MultiCell(17, $h, "$c->qty", 1, 'C', 0, '', '');
$pdf->SetFont('Times','',9);
    $pdf->MultiCell(12, $h, "$c->uom", 1, 'C', 0, '', '');
$pdf->SetFont('Times','',11);
    $pdf->MultiCell(27, $h, (!empty($rate)?'$ '.$rate:''), 1, 'C', 0, '', '');
    $pdf->MultiCell(30, $h, (!empty($total)?'$ '.$total:''), 1, 'C', 0, 1, '', '');
/*$pdf->Cell(65,5,"$c->pname",1,0,'L');
$pdf->Cell(27,15,"$c->qty",1,0,'C');
$pdf->Cell(27,15,"$c->uom",1,0,'C');
$pdf->Cell(27,15,"$c->rate",1,0,'C');
$pdf->Cell(30,15,"$c->total",1,1,'C');
    */


}
$grand_total = number_format($grand_total,2);
$pdf->MultiCell(10, 10, "", 0, 'C', 0, '', '');
    $pdf->MultiCell(95, 10, "", 0, 'L', 0, '', '');
    $pdf->MultiCell(12, 10, "", 0, 'C', 0, '', '');
$pdf->SetFont('Times','',9);
    $pdf->MultiCell(12, 10, "", 0, 'C', 0, '', '');
$pdf->SetFont('Times','',11);
$pdf->Cell(27,10,'Total',1,0,'C', true);
$pdf->Cell(30,10,(!empty($grand_total)?'$ '.$grand_total:''),1,1,'C', true);
 $pdf->Ln(2);
// create some HTML content
$html = "$quote";

// output the HTML content
$pdf->writeHTML($html, true, 0, true, 0);

// reset pointer to the last page
$pdf->lastPage();
 $pdf->Ln(3);
    $pdf->Cell(180,5,"Hence we request your good self to kindly confirm your valuable order",0,1,'L');
$pdf->SetFont('Times','B',11);
$pdf->Cell(180,5,"Yours Faithfully",0,1,'L');
$pdf->Cell(180,5,"For Mohan Mutha Exports",0,1,'L');
$pdf->Ln(5);
$pdf->Cell(180,5,"$director",0,1,'L');
$pdf->Cell(180,5,"$bdm",0,1,'L');

	$pdf->Output();
	exit;

?>

// reset pointer to the last page
$pdf->lastPage();

$pdf->Ln(2);
    
$pdf->SetFont('Times','B',11);
$pdf->Cell(180,5,"Yours Faithfully",0,1,'L');
$pdf->Cell(180,5,"For Mohan Mutha Exports",0,1,'L');
$pdf->Ln(10);
$pdf->Cell(180,5,"$director",0,1,'L');
$pdf->Cell(180,5,"$bdm",0,1,'L');

	$pdf->Output();
	exit;

?>
